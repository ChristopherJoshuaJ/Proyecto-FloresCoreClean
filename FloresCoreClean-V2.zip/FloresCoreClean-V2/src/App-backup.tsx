import { useState, useEffect } from 'react'
import Header from './components/Header'
import Button from './components/Button'
import Products from './components/Products'
import './styles/App.less'

function App() {
  const [currentTheme, setCurrentTheme] = useState('green')
  const [currentPage, setCurrentPage] = useState('home') // 'home', 'products', 'services', 'about', 'contact'

  // Apply theme to document body
  useEffect(() => {
    // Remove all theme classes
    document.body.className = document.body.className.replace(/theme-\w+/g, '').trim()
    // Add new theme class
    document.body.classList.add(`theme-${currentTheme}`)
    
    return () => {
      // Cleanup on unmount
      document.body.className = document.body.className.replace(/theme-\w+/g, '').trim()
    }
  }, [currentTheme])

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme)
  }

  const handleQuoteRequest = () => {
    alert('¡Solicitud de cotización enviada! Nos contactaremos contigo pronto.')
  }

  const handleNavigation = (page: string) => {
    setCurrentPage(page)
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'products':
        return <Products />
      case 'services':
        return (
          <div className="app__page">
            <div className="container">
              <h1>Servicios</h1>
              <p>Página de servicios en construcción...</p>
            </div>
          </div>
        )
      case 'about':
        return (
          <div className="app__page">
            <div className="container">
              <h1>Nosotros</h1>
              <p>Página sobre nosotros en construcción...</p>
            </div>
          </div>
        )
      case 'contact':
        return (
          <div className="app__page">
            <div className="container">
              <h1>Contacto</h1>
              <p>Página de contacto en construcción...</p>
            </div>
          </div>
        )
      default:
        return renderHomePage()
    }
  }

  const renderHomePage = () => (
    <>
      {/* Hero Section */}
      <section className="app__hero">
        <div className="app__hero-content">
          <h1 className="app__hero-title">
            LIMPIEZA QUE <span className="app__hero-highlight">TRANSFORMA</span> TU ESPACIO
          </h1>
          <p className="app__hero-subtitle">
            Lavado, desmanchado y desinfectado de muebles y tapices
          </p>
          <p className="app__hero-location">
            Visita a domicilio GRATIS en Lima, Perú
          </p>
          <div className="app__hero-stats">
            <div className="app__stat-card">
              <div className="app__stat-number">50+</div>
              <div className="app__stat-label">Clientes Satisfechos</div>
            </div>
            <div className="app__stat-card">
              <div className="app__stat-number">5+</div>
              <div className="app__stat-label">Años en el Rubro</div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="app__why-choose">
        <div className="container">
          <h2 className="app__section-title">¿Por Qué Elegirnos?</h2>
          <div className="app__features-grid">
            <div className="app__feature-card">
              <div className="app__feature-icon">🏆</div>
              <h3 className="app__feature-title">Resultados de Calidad</h3>
              <p className="app__feature-description">
                Más de 5 años de experiencia garantizan resultados profesionales que superan tus expectativas.
              </p>
            </div>
            <div className="app__feature-card">
              <div className="app__feature-icon">❤️</div>
              <h3 className="app__feature-title">Atención Personalizada</h3>
              <p className="app__feature-description">
                Cada cliente es único. Adaptamos nuestros servicios a tus necesidades específicas.
              </p>
            </div>
            <div className="app__feature-card">
              <div className="app__feature-icon">🏠</div>
              <h3 className="app__feature-title">Comodidad en Casa</h3>
              <p className="app__feature-description">
                Servicio a domicilio que te permite disfrutar de muebles limpios sin salir de casa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section - Preview */}
      <section id="products" className="app__products">
        <div className="container">
          <h2 className="app__section-title">Nuestros Productos</h2>
          <p className="app__section-subtitle">
            Productos profesionales de limpieza para el cuidado y mantenimiento de tus muebles y tapices
          </p>
          
          <div className="app__products-preview">
            <p>Vista previa de productos destacados...</p>
            <Button 
              variant="primary" 
              size="large"
              onClick={() => handleNavigation('products')}
            >
              Ver Catálogo Completo
            </Button>
          </div>
        </div>
      </section>

      {/* Services Section - Preview */}
      <section id="services" className="app__services">
        <div className="container">
          <h2 className="app__section-title">Nuestros Servicios</h2>
          <p className="app__section-subtitle">
            Servicios profesionales de limpieza para todo tipo de muebles y tapices
          </p>
          
          <div className="app__services-preview">
            <p>Vista previa de servicios destacados...</p>
            <Button 
              variant="outline" 
              size="large"
              onClick={() => handleNavigation('services')}
            >
              Ver Todos los Servicios
            </Button>
          </div>
        </div>
      </section>

      {/* Theme Testing Section */}
      <section className="app__theme-demo">
        <div className="container">
          <h2 className="app__section-title">Configuración del Sistema</h2>
          <div className="app__theme-card">
            <h3>Temas Disponibles</h3>
            <p>Personaliza los colores de la plataforma según las necesidades de tu empresa.</p>
            <div className="app__theme-swatches">
              {['green', 'blue', 'red', 'purple', 'orange'].map(theme => (
                <button
                  key={theme}
                  className={`app__theme-swatch app__theme-swatch--${theme} ${currentTheme === theme ? 'active' : ''}`}
                  onClick={() => handleThemeChange(theme)}
                  title={`Cambiar a tema ${theme}`}
                />
              ))}
            </div>
            <p className="app__current-theme">Tema actual: <strong>{currentTheme}</strong></p>
          </div>
        </div>
      </section>
    </>
  )

  return (
    <div className="app">
      <Header 
        siteName="FloresCore"
        currentTheme={currentTheme}
        onThemeChange={handleThemeChange}
        onQuoteRequest={handleQuoteRequest}
        phoneNumber="+51 999 888 777"
        onNavigation={handleNavigation}
        currentPage={currentPage}
      />
      
      <main className="app__main">
        {renderPage()}
      </main>
    </div>
  )
        {/* Hero Section */}
        <section className="app__hero">
          <div className="app__hero-content">
            <h1 className="app__hero-title">
              LIMPIEZA QUE <span className="app__hero-highlight">TRANSFORMA</span> TU ESPACIO
            </h1>
            <p className="app__hero-subtitle">
              Lavado, desmanchado y desinfectado de muebles y tapices
            </p>
            <p className="app__hero-location">
              Visita a domicilio GRATIS en Lima, Perú
            </p>
            <div className="app__hero-stats">
              <div className="app__stat-card">
                <div className="app__stat-number">50+</div>
                <div className="app__stat-label">Clientes Satisfechos</div>
              </div>
              <div className="app__stat-card">
                <div className="app__stat-number">5+</div>
                <div className="app__stat-label">Años en el Rubro</div>
              </div>
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section className="app__why-choose">
          <div className="container">
            <h2 className="app__section-title">¿Por Qué Elegirnos?</h2>
            <div className="app__features-grid">
              <div className="app__feature-card">
                <div className="app__feature-icon">🏆</div>
                <h3 className="app__feature-title">Resultados de Calidad</h3>
                <p className="app__feature-description">
                  Más de 5 años de experiencia garantizan resultados profesionales que superan tus expectativas.
                </p>
              </div>
              <div className="app__feature-card">
                <div className="app__feature-icon">❤️</div>
                <h3 className="app__feature-title">Atención Personalizada</h3>
                <p className="app__feature-description">
                  Cada cliente es único. Adaptamos nuestros servicios a tus necesidades específicas.
                </p>
              </div>
              <div className="app__feature-card">
                <div className="app__feature-icon">🏠</div>
                <h3 className="app__feature-title">Comodidad en Casa</h3>
                <p className="app__feature-description">
                  Servicio a domicilio que te permite disfrutar de muebles limpios sin salir de casa.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Products Section */}
        <section id="products" className="app__products">
          <div className="container">
            <h2 className="app__section-title">Nuestros Productos</h2>
            <p className="app__section-subtitle">
              Productos profesionales de limpieza para el cuidado y mantenimiento de tus muebles y tapices
            </p>
            
            {/* Product Categories */}
            <div className="app__product-categories">
              <button className="app__category-btn app__category-btn--active">
                Todos
              </button>
              <button className="app__category-btn">
                Protectores
              </button>
              <button className="app__category-btn">
                Limpiadores
              </button>
              <button className="app__category-btn">
                Desodorantes
              </button>
              <button className="app__category-btn">
                Kits Completos
              </button>
            </div>

            <div className="app__products-grid">
              {/* Row 1 */}
              <div className="app__product-card">
                <div className="app__product-badge">BESTSELLER</div>
                <div className="app__product-image">🛡️</div>
                <div className="app__product-category">Protectores</div>
                <h3 className="app__product-title">Protector Antimanchas Profesional</h3>
                <p className="app__product-description">
                  Protección invisible contra manchas líquidas y sólidas. 
                  Ideal para sofás, sillones y tapicería.
                </p>
                <div className="app__product-features">
                  <span>✓ Protección 6 meses</span>
                  <span>✓ Invisible y transpirable</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 55.90</span>
                  <span className="app__price-original">S/ 69.90</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>
              
              <div className="app__product-card">
                <div className="app__product-badge">OFERTA</div>
                <div className="app__product-image">🧴</div>
                <div className="app__product-category">Limpiadores</div>
                <h3 className="app__product-title">Limpiador Enzimático Premium</h3>
                <p className="app__product-description">
                  Fórmula avanzada que elimina manchas orgánicas y olores 
                  desde la raíz del tejido.
                </p>
                <div className="app__product-features">
                  <span>✓ Elimina olores</span>
                  <span>✓ Biodegradable</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 42.50</span>
                  <span className="app__price-original">S/ 52.90</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>
              
              <div className="app__product-card">
                <div className="app__product-image">🌿</div>
                <div className="app__product-category">Desodorantes</div>
                <h3 className="app__product-title">Desodorante Natural Plus</h3>
                <p className="app__product-description">
                  Neutralizador de olores con extractos naturales. 
                  Perfecto para el mantenimiento diario.
                </p>
                <div className="app__product-features">
                  <span>✓ 100% Natural</span>
                  <span>✓ Fragancia duradera</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 28.90</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>

              {/* Row 2 */}
              <div className="app__product-card">
                <div className="app__product-image">✨</div>
                <div className="app__product-category">Limpiadores</div>
                <h3 className="app__product-title">Shampoo para Alfombras</h3>
                <p className="app__product-description">
                  Limpieza profunda para alfombras y tapetes. 
                  Fórmula concentrada de alto rendimiento.
                </p>
                <div className="app__product-features">
                  <span>✓ Concentrado 1:10</span>
                  <span>✓ Secado rápido</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 38.75</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>
              
              <div className="app__product-card">
                <div className="app__product-badge">NUEVO</div>
                <div className="app__product-image">🧽</div>
                <div className="app__product-category">Limpiadores</div>
                <h3 className="app__product-title">Espuma Activa Multiuso</h3>
                <p className="app__product-description">
                  Espuma de acción rápida para manchas difíciles. 
                  Ideal para emergencias y limpieza localizada.
                </p>
                <div className="app__product-features">
                  <span>✓ Acción en 30 seg</span>
                  <span>✓ Sin residuos</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 32.50</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>
              
              <div className="app__product-card">
                <div className="app__product-badge">KIT</div>
                <div className="app__product-image">📦</div>
                <div className="app__product-category">Kits Completos</div>
                <h3 className="app__product-title">Kit Mantenimiento Hogar</h3>
                <p className="app__product-description">
                  Kit completo con protector, limpiador y desodorante. 
                  Todo lo necesario para el cuidado integral.
                </p>
                <div className="app__product-features">
                  <span>✓ 3 productos</span>
                  <span>✓ Ahorro 25%</span>
                </div>
                <div className="app__product-price">
                  <span className="app__price-current">S/ 89.90</span>
                  <span className="app__price-original">S/ 119.90</span>
                </div>
                <Button variant="primary" size="small">Añadir al Carrito</Button>
              </div>
              
              {/* More Products Card */}
              <div className="app__product-card app__product-card--more">
                <div className="app__more-products">
                  <div className="app__more-icon">📋</div>
                  <div className="app__more-text">Ver Catálogo Completo</div>
                  <div className="app__more-subtitle">+15 productos más</div>
                  <Button variant="outline" size="small">Ver Todos</Button>
                </div>
              </div>
            </div>

            {/* Product Benefits */}
            <div className="app__product-benefits">
              <div className="app__benefit-item">
                <div className="app__benefit-icon">🚚</div>
                <div className="app__benefit-text">
                  <strong>Envío Gratis</strong>
                  <span>En compras mayores a S/ 50</span>
                </div>
              </div>
              <div className="app__benefit-item">
                <div className="app__benefit-icon">💯</div>
                <div className="app__benefit-text">
                  <strong>Garantía Total</strong>
                  <span>30 días de satisfacción</span>
                </div>
              </div>
              <div className="app__benefit-item">
                <div className="app__benefit-icon">🔬</div>
                <div className="app__benefit-text">
                  <strong>Calidad Profesional</strong>
                  <span>Productos certificados</span>
                </div>
              </div>
              <div className="app__benefit-item">
                <div className="app__benefit-icon">📞</div>
                <div className="app__benefit-text">
                  <strong>Asesoría Gratis</strong>
                  <span>Consulta con nuestros expertos</span>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Services Section */}
        <section className="app__services">
          <div className="container">
            <h2 className="app__section-title">Servicios</h2>
            <div className="app__services-grid">
              <div className="app__service-card">
                <div className="app__service-image">🛋️</div>
                <h3 className="app__service-title">Lavado de Muebles</h3>
                <p className="app__service-description">
                  Limpieza profunda de sofás, sillones y muebles tapizados. 
                  Eliminamos manchas, olores y ácaros con productos especializados.
                </p>
                <div className="app__service-duration">Duración: 60.00</div>
                <Button variant="outline">Solicitar cotización</Button>
              </div>
              
              <div className="app__service-card">
                <div className="app__service-image">🛏️</div>
                <h3 className="app__service-title">Lavado de Colchones</h3>
                <p className="app__service-description">
                  Limpieza sanitaria profunda que elimina ácaros, bacterias y 
                  malos olores. Ideal para mejorar la calidad del sueño.
                </p>
                <div className="app__service-duration">Duración: 60.00</div>
                <Button variant="outline">Solicitar cotización</Button>
              </div>
              
              <div className="app__service-card">
                <div className="app__service-image">🪟</div>
                <h3 className="app__service-title">Lavado de Cortinas</h3>
                <p className="app__service-description">
                  Limpieza especializada de cortinas y persianas. 
                  Removemos polvo, manchas y alérgenos sin dañar los tejidos.
                </p>
                <div className="app__service-duration">Duración: 40.00</div>
                <Button variant="outline">Solicitar cotización</Button>
              </div>
              
              <div className="app__service-card app__service-card--more">
                <div className="app__more-services">
                  <div className="app__more-text">VER MAS</div>
                  <div className="app__more-icon">+</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Theme Testing Section */}
        <section className="app__theme-demo">
          <div className="container">
            <h2 className="app__section-title">Configuración del Sistema</h2>
            <div className="app__theme-card">
              <h3>Temas Disponibles</h3>
              <p>Personaliza los colores de la plataforma según las necesidades de tu empresa.</p>
              <div className="app__theme-swatches">
                {['green', 'blue', 'red', 'purple', 'orange'].map(theme => (
                  <button
                    key={theme}
                    className={`app__theme-swatch app__theme-swatch--${theme} ${currentTheme === theme ? 'active' : ''}`}
                    onClick={() => handleThemeChange(theme)}
                    title={`Cambiar a tema ${theme}`}
                  />
                ))}
              </div>
              <p className="app__current-theme">Tema actual: <strong>{currentTheme}</strong></p>
            </div>
          </div>
        </section>
      </main>
    </div>
  )
}

export default App
