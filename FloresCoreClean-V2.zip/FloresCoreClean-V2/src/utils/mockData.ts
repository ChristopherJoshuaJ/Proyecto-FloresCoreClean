// ===========================================
// FAKE USER CREDENTIALS FOR DEVELOPMENT
// ===========================================

export interface User {
  id: string;
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  phone: string;
  role: 'user' | 'admin';
  avatar?: string;
  createdAt: string;
  lastLogin?: string;
}

export interface Order {
  id: string;
  userId: string;
  service: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled';
  date: string;
  price: number;
  address: string;
  description: string;
}

export interface PurchaseItem {
  id: string;
  userId: string;
  itemName: string;
  itemType: 'product' | 'service';
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled' | 'delivered' | 'shipped';
  date: string;
  price: number;
  quantity: number;
  address?: string;
  description: string;
  image: string;
}

export interface Service {
  id: string;
  name: string;
  category: string;
  startingPrice: number;
  originalStartingPrice?: number;
  estimatedDuration: string;
  description: string;
  features: string[];
  image: string;
  badge?: string;
  available: boolean;
  rating: number;
  reviews: number;
  onSale?: boolean;
}

export interface CartItem {
  id: string;
  type: 'product' | 'service';
  name: string;
  price: number;
  image: string;
  quantity: number;
  selectedVariant?: string;
  addedAt: string;
}

// Fake User Credentials
export const FAKE_USERS: User[] = [
  {
    id: 'user-001',
    email: 'usuario@test.com',
    password: '123456',
    firstName: 'María',
    lastName: 'González Pérez',
    phone: '+51 999 123 456',
    role: 'user',
    avatar: '👩',
    createdAt: '2024-01-15',
    lastLogin: '2025-10-01'
  },
  {
    id: 'user-002', 
    email: 'admin@florescore.com',
    password: 'admin123',
    firstName: 'Carlos',
    lastName: 'Administrador',
    phone: '+51 999 888 777',
    role: 'admin',
    avatar: '👨‍💼',
    createdAt: '2023-06-01',
    lastLogin: '2025-10-01'
  },
  {
    id: 'user-003',
    email: 'cliente@email.com',
    password: 'cliente123',
    firstName: 'Ana',
    lastName: 'Rodríguez Silva',
    phone: '+51 987 654 321',
    role: 'user',
    avatar: '👩‍💻',
    createdAt: '2024-03-20',
    lastLogin: '2025-09-28'
  }
];

// Fake Orders for demonstration
export const FAKE_ORDERS: Order[] = [
  {
    id: 'order-001',
    userId: 'user-001',
    service: 'Limpieza de Sofá 3 Plazas',
    status: 'completed',
    date: '2025-09-25',
    price: 120.00,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Limpieza profunda de sofá de tela con protección antimanchas'
  },
  {
    id: 'order-002',
    userId: 'user-001',
    service: 'Limpieza de Alfombra',
    status: 'in-progress',
    date: '2025-10-01',
    price: 80.00,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Limpieza de alfombra persa 2x3 metros'
  },
  {
    id: 'order-003',
    userId: 'user-003',
    service: 'Kit Mantenimiento Hogar',
    status: 'pending',
    date: '2025-10-02',
    price: 89.90,
    address: 'Calle Los Olivos 567, Miraflores',
    description: 'Entrega de kit completo de mantenimiento para hogar'
  }
];

// Authentication helper functions
export const authenticateUser = (email: string, password: string): User | null => {
  const user = FAKE_USERS.find(u => u.email === email && u.password === password);
  if (user) {
    // Update last login
    user.lastLogin = new Date().toISOString().split('T')[0];
    return user;
  }
  return null;
};

export const getUserOrders = (userId: string): Order[] => {
  return FAKE_ORDERS.filter(order => order.userId === userId);
};

export const getOrderStatusColor = (status: Order['status']): string => {
  switch (status) {
    case 'completed': return '#5aaf78';
    case 'in-progress': return '#4782c9';
    case 'pending': return '#fb923c';
    case 'cancelled': return '#ff0000';
    default: return '#6b7280';
  }
};

export const getOrderStatusText = (status: Order['status']): string => {
  switch (status) {
    case 'completed': return 'Completado';
    case 'in-progress': return 'En Progreso';
    case 'pending': return 'Pendiente';
    case 'cancelled': return 'Cancelado';
    default: return 'Desconocido';
  }
};

// ===========================================
// SERVICES CATALOG DATA
// ===========================================

export const SERVICES_DATA: Service[] = [
  // Limpieza de Muebles
  {
    id: 'serv-001',
    name: 'Limpieza de Sofá 3 Plazas',
    category: 'furniture',
    startingPrice: 89.90,
    originalStartingPrice: 120.00,
    estimatedDuration: '2-3 horas',
    description: 'Limpieza profunda de sofás de 3 plazas con tratamiento antimanchas incluido. Utilizamos productos especializados según el tipo de tela.',
    features: ['Limpieza profunda', 'Tratamiento antimanchas', 'Productos especializados', 'Secado rápido'],
    image: '🛋️',
    badge: 'POPULAR',
    available: true,
    rating: 4.9,
    reviews: 156,
    onSale: true
  },
  {
    id: 'serv-002',
    name: 'Limpieza de Sillón Individual',
    category: 'furniture',
    startingPrice: 45.00,
    originalStartingPrice: 60.00,
    estimatedDuration: '1-2 horas',
    description: 'Servicio especializado para sillones individuales. Limpieza profunda con productos de alta calidad.',
    features: ['Limpieza especializada', 'Productos premium', 'Tratamiento de manchas', 'Desinfección'],
    image: '🪑',
    badge: 'OFERTA',
    available: true,
    rating: 4.8,
    reviews: 89,
    onSale: true
  },
  {
    id: 'serv-003',
    name: 'Limpieza de Sofá de Cuero',
    category: 'furniture',
    startingPrice: 110.00,
    estimatedDuration: '3-4 horas',
    description: 'Tratamiento especializado para muebles de cuero con productos específicos que nutren y protegen.',
    features: ['Productos específicos para cuero', 'Nutrición del material', 'Protección UV', 'Acabado brillante'],
    image: '🛋️',
    available: true,
    rating: 4.9,
    reviews: 134
  },
  {
    id: 'serv-004',
    name: 'Limpieza de Comedor Completo',
    category: 'furniture',
    startingPrice: 180.00,
    estimatedDuration: '4-6 horas',
    description: 'Limpieza completa de juego de comedor: mesa, sillas y muebles auxiliares.',
    features: ['Servicio completo', 'Múltiples superficies', 'Productos especializados', 'Acabado profesional'],
    image: '🍽️',
    badge: 'PREMIUM',
    available: true,
    rating: 5.0,
    reviews: 67
  },

  // Limpieza de Alfombras
  {
    id: 'serv-005',
    name: 'Limpieza de Alfombra Pequeña',
    category: 'carpets',
    startingPrice: 35.00,
    estimatedDuration: '1-2 horas',
    description: 'Limpieza profesional de alfombras hasta 2x2 metros. Eliminación de manchas y olores.',
    features: ['Hasta 2x2 metros', 'Eliminación de olores', 'Secado rápido', 'Productos eco-friendly'],
    image: '🪣',
    available: true,
    rating: 4.7,
    reviews: 203
  },
  {
    id: 'serv-006',
    name: 'Limpieza de Alfombra Grande',
    category: 'carpets',
    startingPrice: 75.00,
    originalStartingPrice: 95.00,
    estimatedDuration: '3-4 horas',
    description: 'Limpieza profunda de alfombras grandes (hasta 4x3 metros) con maquinaria especializada.',
    features: ['Hasta 4x3 metros', 'Maquinaria especializada', 'Tratamiento antimanchas', 'Desinfección completa'],
    image: '🪣',
    badge: 'BESTSELLER',
    available: true,
    rating: 4.8,
    reviews: 145,
    onSale: true
  },
  {
    id: 'serv-007',
    name: 'Limpieza de Alfombra Persa',
    category: 'carpets',
    startingPrice: 120.00,
    estimatedDuration: '4-5 horas',
    description: 'Servicio especializado para alfombras persas y orientales con técnicas tradicionales.',
    features: ['Técnicas especializadas', 'Cuidado de fibras delicadas', 'Conservación de colores', 'Secado controlado'],
    image: '🕌',
    badge: 'ESPECIALIZADO',
    available: true,
    rating: 5.0,
    reviews: 78
  },

  // Servicios de Hogar
  {
    id: 'serv-008',
    name: 'Limpieza de Cortinas',
    category: 'home',
    startingPrice: 25.00,
    estimatedDuration: '2-3 horas',
    description: 'Limpieza profesional de cortinas sin descolgar. Eliminación de polvo y alérgenos.',
    features: ['Sin descolgar', 'Eliminación de alérgenos', 'Productos especiales', 'Secado rápido'],
    image: '🪟',
    available: true,
    rating: 4.6,
    reviews: 167
  },
  {
    id: 'serv-009',
    name: 'Limpieza de Colchón Individual',
    category: 'home',
    startingPrice: 55.00,
    originalStartingPrice: 70.00,
    estimatedDuration: '2-3 horas',
    description: 'Limpieza profunda de colchones con eliminación de ácaros y bacterias.',
    features: ['Eliminación de ácaros', 'Desinfección profunda', 'Productos hipoalergénicos', 'Secado rápido'],
    image: '🛏️',
    badge: 'SALUDABLE',
    available: true,
    rating: 4.9,
    reviews: 198,
    onSale: true
  },
  {
    id: 'serv-010',
    name: 'Limpieza de Colchón Matrimonial',
    category: 'home',
    startingPrice: 85.00,
    estimatedDuration: '3-4 horas',
    description: 'Servicio completo para colchones matrimoniales con tratamiento antimicrobiano.',
    features: ['Tratamiento antimicrobiano', 'Eliminación profunda de olores', 'Productos certificados', 'Garantía de higiene'],
    image: '🛏️',
    available: true,
    rating: 4.8,
    reviews: 143
  },
  {
    id: 'serv-011',
    name: 'Lavado de Tapicería de Auto',
    category: 'automotive',
    startingPrice: 65.00,
    estimatedDuration: '2-3 horas',
    description: 'Limpieza completa de asientos y tapicería de vehículos con productos automotrices.',
    features: ['Productos automotrices', 'Limpieza de asientos', 'Eliminación de manchas', 'Protección UV'],
    image: '🚗',
    available: true,
    rating: 4.7,
    reviews: 124
  },

  // Servicios Premium
  {
    id: 'serv-012',
    name: 'Paquete Sala Completa',
    category: 'packages',
    startingPrice: 220.00,
    originalStartingPrice: 280.00,
    estimatedDuration: '5-7 horas',
    description: 'Servicio completo para sala: sofás, alfombras, cortinas y muebles auxiliares.',
    features: ['Servicio integral', 'Múltiples superficies', 'Descuento por paquete', 'Garantía extendida'],
    image: '🏠',
    badge: 'PAQUETE',
    available: true,
    rating: 5.0,
    reviews: 89,
    onSale: true
  },
  {
    id: 'serv-013',
    name: 'Mantenimiento Mensual',
    category: 'maintenance',
    startingPrice: 150.00,
    estimatedDuration: '3-4 horas',
    description: 'Plan de mantenimiento mensual para mantener tus muebles como nuevos.',
    features: ['Plan mensual', 'Descuento especial', 'Prioridad en agenda', 'Productos incluidos'],
    image: '📅',
    badge: 'SUSCRIPCIÓN',
    available: true,
    rating: 4.9,
    reviews: 67
  },
  {
    id: 'serv-014',
    name: 'Servicio Express 24h',
    category: 'express',
    startingPrice: 120.00,
    estimatedDuration: '1-2 horas',
    description: 'Servicio de emergencia disponible 24 horas para situaciones urgentes.',
    features: ['Disponible 24h', 'Respuesta rápida', 'Servicio de emergencia', 'Sin costo adicional por horario'],
    image: '⚡',
    badge: 'EXPRESS',
    available: true,
    rating: 4.8,
    reviews: 45
  },
  {
    id: 'serv-015',
    name: 'Tratamiento Antimicrobiano',
    category: 'specialized',
    startingPrice: 95.00,
    estimatedDuration: '2-3 horas',
    description: 'Tratamiento especializado antimicrobiano para entornos que requieren máxima higiene.',
    features: ['Certificación sanitaria', 'Productos hospitalarios', 'Eliminación 99.9% gérmenes', 'Larga duración'],
    image: '🦠',
    badge: 'SANITARIO',
    available: true,
    rating: 5.0,
    reviews: 34
  }
];

// ===========================================
// PURCHASE HISTORY DATA (Products + Services)
// ===========================================

export const PURCHASE_HISTORY: PurchaseItem[] = [
  // Recent Services
  {
    id: 'purchase-001',
    userId: 'user-001',
    itemName: 'Limpieza de Sofá 3 Plazas',
    itemType: 'service',
    status: 'completed',
    date: '2025-09-25',
    price: 89.90,
    quantity: 1,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Limpieza profunda de sofá con tratamiento antimanchas',
    image: '🛋️'
  },
  {
    id: 'purchase-002',
    userId: 'user-001',
    itemName: 'Limpieza de Alfombra Grande',
    itemType: 'service',
    status: 'in-progress',
    date: '2025-10-01',
    price: 75.00,
    quantity: 1,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Limpieza de alfombra persa 3x4 metros',
    image: '🪣'
  },
  
  // Recent Product Purchases
  {
    id: 'purchase-003',
    userId: 'user-001',
    itemName: 'ScotchGard Pro Shield',
    itemType: 'product',
    status: 'delivered',
    date: '2025-09-20',
    price: 89.90,
    quantity: 2,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Protector antimanchas profesional - Pack x2',
    image: '🛡️'
  },
  {
    id: 'purchase-004',
    userId: 'user-001',
    itemName: 'UltraClean Enzyme',
    itemType: 'product',
    status: 'shipped',
    date: '2025-09-28',
    price: 75.00,
    quantity: 1,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Limpiador enzimático para manchas difíciles',
    image: '🧴'
  },
  {
    id: 'purchase-005',
    userId: 'user-001',
    itemName: 'Kit Hogar Completo',
    itemType: 'product',
    status: 'pending',
    date: '2025-10-01',
    price: 199.90,
    quantity: 1,
    address: 'Av. Javier Prado 1234, San Isidro',
    description: 'Kit completo de mantenimiento para hogar',
    image: '📦'
  },

  // User 003 History
  {
    id: 'purchase-006',
    userId: 'user-003',
    itemName: 'Limpieza de Colchón Matrimonial',
    itemType: 'service',
    status: 'completed',
    date: '2025-09-15',
    price: 85.00,
    quantity: 1,
    address: 'Calle Los Olivos 567, Miraflores',
    description: 'Limpieza profunda con tratamiento antimicrobiano',
    image: '🛏️'
  },
  {
    id: 'purchase-007',
    userId: 'user-003',
    itemName: 'Protector UV Plus',
    itemType: 'product',
    status: 'delivered',
    date: '2025-09-10',
    price: 48.50,
    quantity: 3,
    address: 'Calle Los Olivos 567, Miraflores',
    description: 'Protección contra rayos UV para muebles',
    image: '☀️'
  },
  {
    id: 'purchase-008',
    userId: 'user-003',
    itemName: 'Paquete Sala Completa',
    itemType: 'service',
    status: 'pending',
    date: '2025-10-05',
    price: 220.00,
    quantity: 1,
    address: 'Calle Los Olivos 567, Miraflores',
    description: 'Servicio completo: sofás, alfombras y cortinas',
    image: '🏠'
  }
];

// Helper function to get user purchase history
export const getUserPurchases = (userId: string): PurchaseItem[] => {
  return PURCHASE_HISTORY.filter(purchase => purchase.userId === userId)
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

// ===========================================
// ADMIN DASHBOARD DATA
// ===========================================

export interface Reservation {
  id: string;
  clientName: string;
  service: string;
  dateTime: string;
  status: 'pending' | 'in-progress' | 'completed' | 'cancelled' | 'pendiente' | 'en-camino' | 'finalizado';
  price: number;
  address: string;
  clientId: string;
  staffId?: string;
}

export interface Client {
  id: string;
  name: string;
  email: string;
  phone: string;
  bookingHistory: number;
  totalSpent: number;
  lastBooking: string;
  status: 'active' | 'inactive';
}

export interface Staff {
  id: string;
  name: string;
  avatar: string;
  status: 'available' | 'busy';
  currentAssignment?: string;
  completedJobs: number;
  rating: number;
}

export interface AdminService {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  category: string;
  status: 'activo' | 'inactivo';
  bookings: number;
  icon: string;
}

export interface AdminProduct {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  status: 'active' | 'inactive';
}

export interface AdminStats {
  reservationsThisMonth: number;
  revenue: number;
  newClients: number;
  averageRating: number;
}

// Mock admin data
export const ADMIN_RESERVATIONS: Reservation[] = [
  {
    id: 'R001',
    clientName: 'Carlos Vega',
    service: 'Limpieza de Alfombras',
    dateTime: '2025-09-28T10:00:00',
    status: 'finalizado',
    price: 120.00,
    address: 'Av. Javier Prado 1234, San Isidro',
    clientId: 'user-001',
    staffId: 'staff-001'
  },
  {
    id: 'R002',
    clientName: 'Maria Flores',
    service: 'Limpieza de Muebles',
    dateTime: '2025-09-29T14:00:00',
    status: 'en-camino',
    price: 150.00,
    address: 'Calle Los Olivos 567, Miraflores',
    clientId: 'user-003',
    staffId: 'staff-002'
  },
  {
    id: 'R003',
    clientName: 'Juan Quispe',
    service: 'Limpieza de Colchones',
    dateTime: '2025-09-30T09:00:00',
    status: 'pendiente',
    price: 100.00,
    address: 'Jr. Amazonas 890, Lima',
    clientId: 'user-004'
  },
  {
    id: 'R004',
    clientName: 'Ana Rodriguez',
    service: 'Paquete Sala Completa',
    dateTime: '2025-10-01T11:00:00',
    status: 'in-progress',
    price: 220.00,
    address: 'Av. Arequipa 456, San Isidro',
    clientId: 'user-005',
    staffId: 'staff-001'
  }
];

export const ADMIN_CLIENTS: Client[] = [
  {
    id: 'C01',
    name: 'Carlos Vega',
    email: 'cvega@mail.com',
    phone: '987654321',
    bookingHistory: 5,
    totalSpent: 650.00,
    lastBooking: '2025-09-28',
    status: 'active'
  },
  {
    id: 'C02',
    name: 'Maria Flores',
    email: 'mflores@mail.com',
    phone: '912345678',
    bookingHistory: 3,
    totalSpent: 380.00,
    lastBooking: '2025-09-29',
    status: 'active'
  },
  {
    id: 'C03',
    name: 'Juan Quispe',
    email: 'jquispe@mail.com',
    phone: '923456789',
    bookingHistory: 2,
    totalSpent: 200.00,
    lastBooking: '2025-09-30',
    status: 'active'
  },
  {
    id: 'C04',
    name: 'Ana Rodriguez',
    email: 'arodriguez@mail.com',
    phone: '934567890',
    bookingHistory: 7,
    totalSpent: 890.00,
    lastBooking: '2025-10-01',
    status: 'active'
  }
];

export const ADMIN_STAFF: Staff[] = [
  {
    id: 'staff-001',
    name: 'Juan Perez',
    avatar: '👨‍🔧',
    status: 'available',
    completedJobs: 45,
    rating: 4.8
  },
  {
    id: 'staff-002',
    name: 'Ana Garcia',
    avatar: '👩‍🔧',
    status: 'busy',
    currentAssignment: 'Limpieza de Muebles - Maria Flores',
    completedJobs: 38,
    rating: 4.9
  },
  {
    id: 'staff-003',
    name: 'Miguel Torres',
    avatar: '👨‍🔧',
    status: 'available',
    completedJobs: 52,
    rating: 4.7
  },
  {
    id: 'staff-004',
    name: 'Sofia Martinez',
    avatar: '👩‍🔧',
    status: 'busy',
    currentAssignment: 'Mantenimiento - Cliente VIP',
    completedJobs: 41,
    rating: 5.0
  }
];

export const ADMIN_SERVICES: AdminService[] = [
  {
    id: 'admin-serv-001',
    name: 'Limpieza de Muebles',
    description: 'Limpieza profunda de sofás, sillones y muebles tapizados',
    price: 120.00,
    duration: '2-3 horas',
    category: 'limpieza',
    status: 'activo',
    bookings: 45,
    icon: '🛋️'
  },
  {
    id: 'admin-serv-002',
    name: 'Limpieza de Alfombras',
    description: 'Limpieza profesional de alfombras y tapetes',
    price: 150.00,
    duration: '3-4 horas',
    category: 'limpieza',
    status: 'activo',
    bookings: 38,
    icon: '🪣'
  },
  {
    id: 'admin-serv-003',
    name: 'Limpieza de Colchones',
    description: 'Desinfección y limpieza profunda de colchones',
    price: 100.00,
    duration: '1-2 horas',
    category: 'limpieza',
    status: 'activo',
    bookings: 52,
    icon: '🛏️'
  },
  {
    id: 'admin-serv-004',
    name: 'Limpieza de Cortinas',
    description: 'Lavado y planchado profesional de cortinas',
    price: 80.00,
    duration: '2-3 horas',
    category: 'limpieza',
    status: 'activo',
    bookings: 28,
    icon: '🪟'
  },
  {
    id: 'admin-serv-005',
    name: 'Servicio Express',
    description: 'Limpieza rápida para emergencias',
    price: 180.00,
    duration: '1 hora',
    category: 'especializado',
    status: 'inactivo',
    bookings: 12,
    icon: '⚡'
  }
];

export const ADMIN_PRODUCTS: AdminProduct[] = [
  {
    id: 'P001',
    name: 'Limpiador Multiusos',
    category: 'Limpieza',
    price: 25.00,
    stock: 50,
    status: 'active'
  },
  {
    id: 'P002',
    name: 'Protector de Telas',
    category: 'Protectores',
    price: 35.00,
    stock: 30,
    status: 'active'
  },
  {
    id: 'P003',
    name: 'Desinfectante Premium',
    category: 'Limpieza',
    price: 45.00,
    stock: 8,
    status: 'active'
  },
  {
    id: 'P004',
    name: 'Kit de Mantenimiento',
    category: 'Accesorios',
    price: 89.90,
    stock: 25,
    status: 'active'
  },
  {
    id: 'P005',
    name: 'Eliminador de Olores',
    category: 'Limpieza',
    price: 28.50,
    stock: 15,
    status: 'active'
  }
];

export const ADMIN_STATS: AdminStats = {
  reservationsThisMonth: 124,
  revenue: 18500,
  newClients: 32,
  averageRating: 5.0
};

// Admin helper functions
export const getAllReservations = (): Reservation[] => {
  return ADMIN_RESERVATIONS.sort((a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime());
};

export const getAllClients = (): Client[] => {
  return ADMIN_CLIENTS.sort((a, b) => new Date(b.lastBooking).getTime() - new Date(a.lastBooking).getTime());
};

export const getAllStaff = (): Staff[] => {
  return ADMIN_STAFF;
};

export const getAdminServices = (): AdminService[] => {
  return ADMIN_SERVICES.sort((a, b) => b.bookings - a.bookings);
};

export const getAdminProducts = (): AdminProduct[] => {
  return ADMIN_PRODUCTS.sort((a, b) => a.stock - b.stock);
};

export const getAdminStats = (): AdminStats => {
  return ADMIN_STATS;
};