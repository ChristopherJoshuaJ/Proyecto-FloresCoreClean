import React, { useState } from 'react';
import Button from '../Button';
import type { User, CartItem, PurchaseItem } from '../../utils/mockData';
import { getUserOrders, getUserPurchases, getOrderStatusColor, getOrderStatusText } from '../../utils/mockData';
import './UserDashboard.less';

export interface UserDashboardProps {
  user: User;
  onLogout: () => void;
  onNavigation: (page: string, tab?: string) => void;
  currentTheme: string;
  onThemeChange: (theme: string) => void;
  cartItems?: CartItem[];
  onRemoveFromCart?: (itemId: string, type: 'product' | 'service', selectedVariant?: string) => void;
  onUpdateCartQuantity?: (itemId: string, type: 'product' | 'service', quantity: number, selectedVariant?: string) => void;
  onClearCart?: () => void;
  cartTotal?: number;
  cartItemCount?: number;
  initialTab?: 'overview' | 'orders' | 'cart' | 'profile' | 'settings';
}

const UserDashboard: React.FC<UserDashboardProps> = ({
  user,
  onLogout,
  onNavigation,
  currentTheme,
  onThemeChange,
  cartItems = [],
  onRemoveFromCart,
  onUpdateCartQuantity,
  onClearCart,
  cartTotal = 0,
  cartItemCount = 0,
  initialTab = 'overview'
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'cart' | 'profile' | 'settings'>(initialTab);
  const userOrders = getUserOrders(user.id);
  const userPurchases = getUserPurchases(user.id);
  
  const completedOrders = userOrders.filter(order => order.status === 'completed');
  const activeOrders = userOrders.filter(order => order.status === 'in-progress' || order.status === 'pending');
  const totalSpent = completedOrders.reduce((sum, order) => sum + order.price, 0) + 
                   userPurchases.filter(p => p.status === 'completed' || p.status === 'delivered').reduce((sum, p) => sum + (p.price * p.quantity), 0);

  const handleRequestService = () => {
    onNavigation('services');
  };

  const handleViewProducts = () => {
    onNavigation('products');
  };

  const getPurchaseStatusColor = (status: PurchaseItem['status']): string => {
    switch (status) {
      case 'completed':
      case 'delivered': return '#5aaf78';
      case 'in-progress': 
      case 'shipped': return '#4782c9';
      case 'pending': return '#fb923c';
      case 'cancelled': return '#ff0000';
      default: return '#6b7280';
    }
  };

  const getPurchaseStatusText = (status: PurchaseItem['status']): string => {
    switch (status) {
      case 'completed': return 'Completado';
      case 'delivered': return 'Entregado';
      case 'in-progress': return 'En Progreso';
      case 'shipped': return 'Enviado';
      case 'pending': return 'Pendiente';
      case 'cancelled': return 'Cancelado';
      default: return 'Desconocido';
    }
  };

  const renderOverview = () => (
    <div className="dashboard__overview">
      <div className="dashboard__welcome">
        <div className="dashboard__welcome-content">
          <div className="dashboard__avatar">{user.avatar}</div>
          <div>
            <h2 className="dashboard__welcome-title">
              ¡Bienvenido, {user.firstName}!
            </h2>
            <p className="dashboard__welcome-subtitle">
              Tu panel de control personal
            </p>
          </div>
        </div>
        <div className="dashboard__quick-actions">
          <Button variant="primary" onClick={handleRequestService}>
            Solicitar Servicio
          </Button>
          <Button variant="outline" onClick={handleViewProducts}>
            Ver Productos
          </Button>
        </div>
      </div>

      <div className="dashboard__stats">
        <div className="dashboard__stat-card">
          <div className="dashboard__stat-icon">📋</div>
          <div className="dashboard__stat-content">
            <h3 className="dashboard__stat-number">{userOrders.length}</h3>
            <p className="dashboard__stat-label">Servicios Totales</p>
          </div>
        </div>
        
        <div className="dashboard__stat-card">
          <div className="dashboard__stat-icon">✅</div>
          <div className="dashboard__stat-content">
            <h3 className="dashboard__stat-number">{completedOrders.length}</h3>
            <p className="dashboard__stat-label">Completados</p>
          </div>
        </div>

        <div className="dashboard__stat-card">
          <div className="dashboard__stat-icon">⏳</div>
          <div className="dashboard__stat-content">
            <h3 className="dashboard__stat-number">{activeOrders.length}</h3>
            <p className="dashboard__stat-label">En Proceso</p>
          </div>
        </div>

        <div className="dashboard__stat-card">
          <div className="dashboard__stat-icon">💰</div>
          <div className="dashboard__stat-content">
            <h3 className="dashboard__stat-number">S/ {totalSpent.toFixed(2)}</h3>
            <p className="dashboard__stat-label">Total Gastado</p>
          </div>
        </div>
      </div>

      <div className="dashboard__recent">
        <h3 className="dashboard__section-title">Servicios Recientes</h3>
        {userOrders.length > 0 ? (
          <div className="dashboard__orders-preview">
            {userOrders.slice(0, 3).map(order => (
              <div key={order.id} className="dashboard__order-card">
                <div className="dashboard__order-info">
                  <h4 className="dashboard__order-service">{order.service}</h4>
                  <p className="dashboard__order-date">{new Date(order.date).toLocaleDateString('es-ES')}</p>
                  <p className="dashboard__order-address">{order.address}</p>
                </div>
                <div className="dashboard__order-status">
                  <span 
                    className="dashboard__status-badge"
                    style={{ backgroundColor: getOrderStatusColor(order.status) }}
                  >
                    {getOrderStatusText(order.status)}
                  </span>
                  <span className="dashboard__order-price">S/ {order.price.toFixed(2)}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="dashboard__empty-state">
            <div className="dashboard__empty-icon">📝</div>
            <h4>No tienes servicios aún</h4>
            <p>¡Solicita tu primer servicio de limpieza!</p>
            <Button variant="primary" onClick={handleRequestService}>
              Solicitar Ahora
            </Button>
          </div>
        )}
      </div>
    </div>
  );

  const renderOrders = () => (
    <div className="dashboard__orders">
      <h3 className="dashboard__section-title">Mi Historial de Compras</h3>
      
      {(userOrders.length > 0 || userPurchases.length > 0) ? (
        <div className="dashboard__orders-content">
          <div className="dashboard__section-header">
            <div className="dashboard__orders-summary">
              <div className="dashboard__summary-item">
                <span className="dashboard__summary-number">{userPurchases.length + userOrders.length}</span>
                <span className="dashboard__summary-label">Total de Órdenes</span>
              </div>
              <div className="dashboard__summary-item">
                <span className="dashboard__summary-number">{userPurchases.filter(p => p.itemType === 'product').length}</span>
                <span className="dashboard__summary-label">Productos</span>
              </div>
              <div className="dashboard__summary-item">
                <span className="dashboard__summary-number">{userOrders.length + userPurchases.filter(p => p.itemType === 'service').length}</span>
                <span className="dashboard__summary-label">Servicios</span>
              </div>
            </div>
          </div>

          <div className="dashboard__orders-list">
            {/* Combined and sorted history */}
            {[...userPurchases, ...userOrders.map(order => ({
              id: order.id,
              userId: order.userId,
              itemName: order.service,
              itemType: 'service' as const,
              status: order.status,
              date: order.date,
              price: order.price,
              quantity: 1,
              address: order.address,
              description: order.description,
              image: '🔧'
            }))].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).map((item) => (
              <div key={item.id} className="dashboard__order-card">
                <div className="dashboard__order-header">
                  <div className="dashboard__order-image">{item.image}</div>
                  <div className="dashboard__order-info">
                    <h4 className="dashboard__order-title">{item.itemName}</h4>
                    <div className="dashboard__order-type">
                      {item.itemType === 'service' ? '🔧 Servicio' : '📦 Producto'}
                      {item.quantity > 1 && <span> - Cantidad: {item.quantity}</span>}
                    </div>
                    <div className="dashboard__order-date">
                      📅 {new Date(item.date).toLocaleDateString('es-ES')}
                    </div>
                  </div>
                  <div className="dashboard__order-status">
                    <span 
                      className="dashboard__status-badge"
                      style={{ backgroundColor: getPurchaseStatusColor(item.status) }}
                    >
                      {getPurchaseStatusText(item.status)}
                    </span>
                  </div>
                  <div className="dashboard__order-price">
                    S/. {(item.price * item.quantity).toFixed(2)}
                  </div>
                </div>
                
                <div className="dashboard__order-description">
                  <p>{item.description}</p>
                  {item.address && (
                    <div className="dashboard__order-address">
                      📍 {item.address}
                    </div>
                  )}
                </div>

                <div className="dashboard__order-actions">
                  {item.itemType === 'service' && (item.status === 'completed') && (
                    <Button variant="outline" size="small">
                      ⭐ Calificar Servicio
                    </Button>
                  )}
                  {item.itemType === 'product' && (item.status === 'delivered') && (
                    <Button variant="outline" size="small">
                      ⭐ Calificar Producto
                    </Button>
                  )}
                  {(item.status === 'pending' || item.status === 'in-progress') && (
                    <Button variant="outline" size="small">
                      📝 Modificar
                    </Button>
                  )}
                  <Button variant="outline" size="small">
                    📄 Ver Detalles
                  </Button>
                  {item.itemType === 'product' && item.status === 'delivered' && (
                    <Button variant="primary" size="small">
                      🔄 Recomprar
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="dashboard__empty-state">
          <div className="dashboard__empty-icon">📋</div>
          <h4>No hay historial de compras</h4>
          <p>Cuando compres productos o solicites servicios, aparecerán aquí.</p>
          <div className="dashboard__empty-actions">
            <Button variant="primary" onClick={() => onNavigation('products')}>
              Ver Productos
            </Button>
            <Button variant="outline" onClick={() => onNavigation('services')}>
              Ver Servicios
            </Button>
          </div>
        </div>
      )}
    </div>
  );

  const renderProfile = () => (
    <div className="dashboard__profile">
      <h3 className="dashboard__section-title">Mi Perfil</h3>
      
      <div className="dashboard__profile-card">
        <div className="dashboard__profile-avatar">
          <div className="dashboard__avatar dashboard__avatar--large">{user.avatar}</div>
          <Button variant="outline" size="small">Cambiar Foto</Button>
        </div>
        
        <div className="dashboard__profile-info">
          <div className="dashboard__profile-field">
            <label className="dashboard__field-label">Nombre Completo</label>
            <div className="dashboard__field-value">{user.firstName} {user.lastName}</div>
          </div>
          
          <div className="dashboard__profile-field">
            <label className="dashboard__field-label">Correo Electrónico</label>
            <div className="dashboard__field-value">{user.email}</div>
          </div>
          
          <div className="dashboard__profile-field">
            <label className="dashboard__field-label">Teléfono</label>
            <div className="dashboard__field-value">{user.phone}</div>
          </div>
          
          <div className="dashboard__profile-field">
            <label className="dashboard__field-label">Tipo de Usuario</label>
            <div className="dashboard__field-value">
              <span className={`dashboard__role-badge dashboard__role-badge--${user.role}`}>
                {user.role === 'admin' ? '👨‍💼 Administrador' : '👤 Cliente'}
              </span>
            </div>
          </div>
          
          <div className="dashboard__profile-field">
            <label className="dashboard__field-label">Miembro desde</label>
            <div className="dashboard__field-value">
              {new Date(user.createdAt).toLocaleDateString('es-ES', { 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric' 
              })}
            </div>
          </div>
        </div>
      </div>

      <div className="dashboard__profile-actions">
        <Button variant="primary">Editar Perfil</Button>
        <Button variant="outline">Cambiar Contraseña</Button>
        <Button variant="outline" className="dashboard__logout-btn" onClick={onLogout}>
          🚪 Cerrar Sesión
        </Button>
      </div>
    </div>
  );

  const renderCart = () => (
    <div className="dashboard__cart">
      <h3 className="dashboard__section-title">Mi Carrito de Compras</h3>
      
      {cartItems.length > 0 ? (
        <div className="dashboard__cart-content">
          <div className="dashboard__cart-header">
            <div className="dashboard__cart-summary">
              <span className="dashboard__cart-count">{cartItemCount} artículo{cartItemCount !== 1 ? 's' : ''}</span>
              <span className="dashboard__cart-total">Total: S/. {cartTotal.toFixed(2)}</span>
            </div>
            {onClearCart && (
              <Button variant="outline" size="small" onClick={onClearCart}>
                Vaciar Carrito
              </Button>
            )}
          </div>

          <div className="dashboard__cart-items">
            {cartItems.map((item, index) => (
              <div key={`${item.type}-${item.id}-${item.selectedVariant || 'default'}-${index}`} className="dashboard__cart-item">
                <div className="dashboard__cart-item-image">{item.image}</div>
                <div className="dashboard__cart-item-details">
                  <h4 className="dashboard__cart-item-name">{item.name}</h4>
                  <div className="dashboard__cart-item-type">
                    {item.type === 'service' ? '🔧 Servicio' : '📦 Producto'}
                    {item.selectedVariant && <span> - {item.selectedVariant}</span>}
                  </div>
                  <div className="dashboard__cart-item-price">S/. {item.price.toFixed(2)} c/u</div>
                </div>
                <div className="dashboard__cart-item-quantity">
                  <button 
                    className="dashboard__quantity-btn"
                    onClick={() => onUpdateCartQuantity?.(item.id, item.type, item.quantity - 1, item.selectedVariant)}
                    disabled={item.quantity <= 1}
                  >
                    -
                  </button>
                  <span className="dashboard__quantity-display">{item.quantity}</span>
                  <button 
                    className="dashboard__quantity-btn"
                    onClick={() => onUpdateCartQuantity?.(item.id, item.type, item.quantity + 1, item.selectedVariant)}
                  >
                    +
                  </button>
                </div>
                <div className="dashboard__cart-item-subtotal">
                  S/. {(item.price * item.quantity).toFixed(2)}
                </div>
                <button 
                  className="dashboard__cart-item-remove"
                  onClick={() => onRemoveFromCart?.(item.id, item.type, item.selectedVariant)}
                  title="Eliminar del carrito"
                >
                  🗑️
                </button>
              </div>
            ))}
          </div>

          <div className="dashboard__cart-actions">
            <Button variant="outline" onClick={() => onNavigation('products')}>
              Seguir Comprando
            </Button>
            <Button variant="primary">
              Proceder al Pago
            </Button>
          </div>
        </div>
      ) : (
        <div className="dashboard__empty-cart">
          <div className="dashboard__empty-icon">🛒</div>
          <h4>Tu carrito está vacío</h4>
          <p>Agrega productos o servicios para comenzar tu compra.</p>
          <div className="dashboard__empty-actions">
            <Button variant="primary" onClick={() => onNavigation('products')}>
              Ver Productos
            </Button>
            <Button variant="outline" onClick={() => onNavigation('services')}>
              Ver Servicios
            </Button>
          </div>
        </div>
      )}
    </div>
  );

  const renderSettings = () => {
    const themes = [
      { value: 'green', label: 'Verde', color: '#5aaf78' },
      { value: 'blue', label: 'Azul', color: '#4782c9' },
      { value: 'red', label: 'Rojo', color: '#ff0000' },
      { value: 'purple', label: 'Morado', color: '#2f2c79' },
      { value: 'orange', label: 'Naranja', color: '#ff4711' },
    ];

    return (
      <div className="dashboard__settings">
        <h3 className="dashboard__section-title">Configuración</h3>
        
        <div className="dashboard__settings-section">
          <h4 className="dashboard__settings-subtitle">Apariencia</h4>
          <div className="dashboard__theme-selector">
            <label className="dashboard__field-label">Tema de color</label>
            <div className="dashboard__theme-options">
              {themes.map((theme) => (
                <button
                  key={theme.value}
                  className={`dashboard__theme-option ${currentTheme === theme.value ? 'active' : ''}`}
                  onClick={() => onThemeChange(theme.value)}
                  style={{ '--theme-color': theme.color } as React.CSSProperties}
                  title={`Cambiar a tema ${theme.label}`}
                >
                  <div className="dashboard__theme-color" style={{ backgroundColor: theme.color }}></div>
                  <span className="dashboard__theme-label">{theme.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="dashboard__settings-section">
          <h4 className="dashboard__settings-subtitle">Notificaciones</h4>
          <div className="dashboard__setting-item">
            <label className="dashboard__setting-label">
              <input type="checkbox" className="dashboard__setting-checkbox" defaultChecked />
              Recibir notificaciones por email
            </label>
          </div>
          <div className="dashboard__setting-item">
            <label className="dashboard__setting-label">
              <input type="checkbox" className="dashboard__setting-checkbox" defaultChecked />
              Notificaciones de servicios programados
            </label>
          </div>
        </div>

        <div className="dashboard__settings-section">
          <h4 className="dashboard__settings-subtitle">Privacidad</h4>
          <div className="dashboard__setting-item">
            <label className="dashboard__setting-label">
              <input type="checkbox" className="dashboard__setting-checkbox" />
              Permitir marketing personalizado
            </label>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="dashboard">
      <div className="dashboard__container">
        <div className="dashboard__sidebar">
          <div className="dashboard__user-info">
            <div className="dashboard__avatar">{user.avatar}</div>
            <div>
              <h3 className="dashboard__user-name">{user.firstName} {user.lastName}</h3>
              <p className="dashboard__user-role">
                {user.role === 'admin' ? 'Administrador' : 'Cliente'}
              </p>
            </div>
          </div>

          <nav className="dashboard__nav">
            <button
              className={`dashboard__nav-item ${activeTab === 'overview' ? 'active' : ''}`}
              onClick={() => setActiveTab('overview')}
            >
              📊 Resumen
            </button>
            <button
              className={`dashboard__nav-item ${activeTab === 'orders' ? 'active' : ''}`}
              onClick={() => setActiveTab('orders')}
            >
              📋 Mi Historial
            </button>
            <button
              className={`dashboard__nav-item ${activeTab === 'cart' ? 'active' : ''}`}
              onClick={() => setActiveTab('cart')}
            >
              🛒 Carrito ({cartItemCount})
            </button>
            <button
              className={`dashboard__nav-item ${activeTab === 'profile' ? 'active' : ''}`}
              onClick={() => setActiveTab('profile')}
            >
              👤 Mi Perfil
            </button>
            <button
              className={`dashboard__nav-item ${activeTab === 'settings' ? 'active' : ''}`}
              onClick={() => setActiveTab('settings')}
            >
              ⚙️ Configuración
            </button>
          </nav>

          <div className="dashboard__sidebar-footer">
            <Button variant="outline" onClick={() => onNavigation('home')}>
              🏠 Ir al Inicio
            </Button>
          </div>
        </div>

        <div className="dashboard__content">
          {activeTab === 'overview' && renderOverview()}
          {activeTab === 'orders' && renderOrders()}
          {activeTab === 'cart' && renderCart()}
          {activeTab === 'profile' && renderProfile()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </div>
    </div>
  );
};

export default UserDashboard;