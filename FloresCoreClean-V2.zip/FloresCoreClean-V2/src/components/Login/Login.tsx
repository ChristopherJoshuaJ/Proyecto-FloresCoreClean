import React, { useState } from 'react';
import Button from '../Button';
import './Login.less';

export interface LoginProps {
  className?: string;
  onLogin?: (credentials: LoginCredentials) => void;
  onRegister?: () => void;
  onForgotPassword?: () => void;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe?: boolean;
}

const Login: React.FC<LoginProps> = ({
  className = '',
  onLogin,
  // onRegister,
  // onForgotPassword
}) => {
  const [formMode, setFormMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    confirmPassword: '',
    firstName: '',
    lastName: '',
    phone: '',
    rememberMe: false
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isLoading, setIsLoading] = useState(false);

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.email) {
      newErrors.email = 'El correo electrónico es requerido';
    } else if (!validateEmail(formData.email)) {
      newErrors.email = 'Ingresa un correo electrónico válido';
    }

    if (formMode !== 'forgot') {
      if (!formData.password) {
        newErrors.password = 'La contraseña es requerida';
      } else if (formData.password.length < 6) {
        newErrors.password = 'La contraseña debe tener al menos 6 caracteres';
      }
    }

    if (formMode === 'register') {
      if (!formData.firstName) {
        newErrors.firstName = 'El nombre es requerido';
      }
      if (!formData.lastName) {
        newErrors.lastName = 'Los apellidos son requeridos';
      }
      if (!formData.phone) {
        newErrors.phone = 'El teléfono es requerido';
      }
      if (formData.password !== formData.confirmPassword) {
        newErrors.confirmPassword = 'Las contraseñas no coinciden';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      if (formMode === 'login' && onLogin) {
        onLogin({
          email: formData.email,
          password: formData.password,
          rememberMe: formData.rememberMe
        });
      } else if (formMode === 'register') {
        alert('¡Registro exitoso! Ahora puedes iniciar sesión.');
        setFormMode('login');
      } else if (formMode === 'forgot') {
        alert('Se ha enviado un enlace de recuperación a tu correo electrónico.');
        setFormMode('login');
      }
      setIsLoading(false);
    }, 1500);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    
    // Clear error when user starts typing
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const renderLoginForm = () => (
    <>
      <div className="login__form-group">
        <label className="login__label" htmlFor="email">
          Correo Electrónico
        </label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          className={`login__input ${errors.email ? 'login__input--error' : ''}`}
          placeholder="ejemplo@correo.com"
          required
        />
        {errors.email && <span className="login__error">{errors.email}</span>}
      </div>

      <div className="login__form-group">
        <label className="login__label" htmlFor="password">
          Contraseña
        </label>
        <input
          type="password"
          id="password"
          name="password"
          value={formData.password}
          onChange={handleInputChange}
          className={`login__input ${errors.password ? 'login__input--error' : ''}`}
          placeholder="••••••••"
          required
        />
        {errors.password && <span className="login__error">{errors.password}</span>}
      </div>

      <div className="login__form-options">
        <label className="login__checkbox-label">
          <input
            type="checkbox"
            name="rememberMe"
            checked={formData.rememberMe}
            onChange={handleInputChange}
            className="login__checkbox"
          />
          <span className="login__checkbox-text">Recordarme</span>
        </label>
        <button
          type="button"
          className="login__link"
          onClick={() => setFormMode('forgot')}
        >
          ¿Olvidaste tu contraseña?
        </button>
      </div>
    </>
  );

  const renderRegisterForm = () => (
    <>
      <div className="login__form-row">
        <div className="login__form-group">
          <label className="login__label" htmlFor="firstName">
            Nombre
          </label>
          <input
            type="text"
            id="firstName"
            name="firstName"
            value={formData.firstName}
            onChange={handleInputChange}
            className={`login__input ${errors.firstName ? 'login__input--error' : ''}`}
            placeholder="Tu nombre"
            required
          />
          {errors.firstName && <span className="login__error">{errors.firstName}</span>}
        </div>

        <div className="login__form-group">
          <label className="login__label" htmlFor="lastName">
            Apellidos
          </label>
          <input
            type="text"
            id="lastName"
            name="lastName"
            value={formData.lastName}
            onChange={handleInputChange}
            className={`login__input ${errors.lastName ? 'login__input--error' : ''}`}
            placeholder="Tus apellidos"
            required
          />
          {errors.lastName && <span className="login__error">{errors.lastName}</span>}
        </div>
      </div>

      <div className="login__form-group">
        <label className="login__label" htmlFor="email">
          Correo Electrónico
        </label>
        <input
          type="email"
          id="email"
          name="email"
          value={formData.email}
          onChange={handleInputChange}
          className={`login__input ${errors.email ? 'login__input--error' : ''}`}
          placeholder="ejemplo@correo.com"
          required
        />
        {errors.email && <span className="login__error">{errors.email}</span>}
      </div>

      <div className="login__form-group">
        <label className="login__label" htmlFor="phone">
          Teléfono
        </label>
        <input
          type="tel"
          id="phone"
          name="phone"
          value={formData.phone}
          onChange={handleInputChange}
          className={`login__input ${errors.phone ? 'login__input--error' : ''}`}
          placeholder="+51 999 888 777"
          required
        />
        {errors.phone && <span className="login__error">{errors.phone}</span>}
      </div>

      <div className="login__form-row">
        <div className="login__form-group">
          <label className="login__label" htmlFor="password">
            Contraseña
          </label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleInputChange}
            className={`login__input ${errors.password ? 'login__input--error' : ''}`}
            placeholder="••••••••"
            required
          />
          {errors.password && <span className="login__error">{errors.password}</span>}
        </div>

        <div className="login__form-group">
          <label className="login__label" htmlFor="confirmPassword">
            Confirmar Contraseña
          </label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formData.confirmPassword}
            onChange={handleInputChange}
            className={`login__input ${errors.confirmPassword ? 'login__input--error' : ''}`}
            placeholder="••••••••"
            required
          />
          {errors.confirmPassword && <span className="login__error">{errors.confirmPassword}</span>}
        </div>
      </div>
    </>
  );

  const renderForgotForm = () => (
    <div className="login__form-group">
      <label className="login__label" htmlFor="email">
        Correo Electrónico
      </label>
      <input
        type="email"
        id="email"
        name="email"
        value={formData.email}
        onChange={handleInputChange}
        className={`login__input ${errors.email ? 'login__input--error' : ''}`}
        placeholder="ejemplo@correo.com"
        required
      />
      {errors.email && <span className="login__error">{errors.email}</span>}
      <p className="login__help-text">
        Te enviaremos un enlace para restablecer tu contraseña.
      </p>
    </div>
  );

  const getFormTitle = () => {
    switch (formMode) {
      case 'register': return 'Crear Cuenta';
      case 'forgot': return 'Recuperar Contraseña';
      default: return 'Iniciar Sesión';
    }
  };

  const getSubmitButtonText = () => {
    if (isLoading) return 'Cargando...';
    switch (formMode) {
      case 'register': return 'Crear Cuenta';
      case 'forgot': return 'Enviar Enlace';
      default: return 'Iniciar Sesión';
    }
  };

  return (
    <div className={`login ${className}`}>
      <div className="login__container">
        <div className="login__card">
          <div className="login__header">
            <h1 className="login__title">{getFormTitle()}</h1>
            <p className="login__subtitle">
              {formMode === 'login' && 'Accede a tu cuenta para gestionar tus pedidos'}
              {formMode === 'register' && 'Únete a nosotros y disfruta de beneficios exclusivos'}
              {formMode === 'forgot' && 'No te preocupes, te ayudamos a recuperar tu acceso'}
            </p>
          </div>

          <form className="login__form" onSubmit={handleSubmit}>
            {formMode === 'login' && renderLoginForm()}
            {formMode === 'register' && renderRegisterForm()}
            {formMode === 'forgot' && renderForgotForm()}

            <Button
              type="submit"
              variant="primary"
              size="large"
              className="login__submit-btn"
              disabled={isLoading}
            >
              {getSubmitButtonText()}
            </Button>
          </form>

          <div className="login__footer">
            {formMode === 'login' && (
              <>
                <p className="login__footer-text">
                  ¿No tienes cuenta?{' '}
                  <button
                    type="button"
                    className="login__link"
                    onClick={() => setFormMode('register')}
                  >
                    Regístrate aquí
                  </button>
                </p>
              </>
            )}
            
            {formMode === 'register' && (
              <p className="login__footer-text">
                ¿Ya tienes cuenta?{' '}
                <button
                  type="button"
                  className="login__link"
                  onClick={() => setFormMode('login')}
                >
                  Inicia sesión
                </button>
              </p>
            )}

            {formMode === 'forgot' && (
              <p className="login__footer-text">
                ¿Recordaste tu contraseña?{' '}
                <button
                  type="button"
                  className="login__link"
                  onClick={() => setFormMode('login')}
                >
                  Volver al login
                </button>
              </p>
            )}
          </div>

          <div className="login__divider">
            <span>o</span>
          </div>

          <div className="login__social">
            <Button
              variant="outline"
              className="login__social-btn"
              onClick={() => alert('Login con Google próximamente')}
            >
              <span className="login__social-icon">📧</span>
              Continuar con Google
            </Button>
            <Button
              variant="outline"
              className="login__social-btn"
              onClick={() => alert('Login con Facebook próximamente')}
            >
              <span className="login__social-icon">📘</span>
              Continuar con Facebook
            </Button>
          </div>
        </div>

        <div className="login__benefits">
          <h3 className="login__benefits-title">¿Por qué crear una cuenta?</h3>
          <ul className="login__benefits-list">
            <li className="login__benefit-item">
              <span className="login__benefit-icon">🚚</span>
              <div>
                <strong>Seguimiento de pedidos</strong>
                <p>Mantente al día con el estado de tus servicios</p>
              </div>
            </li>
            <li className="login__benefit-item">
              <span className="login__benefit-icon">⭐</span>
              <div>
                <strong>Descuentos exclusivos</strong>
                <p>Accede a ofertas especiales solo para miembros</p>
              </div>
            </li>
            <li className="login__benefit-item">
              <span className="login__benefit-icon">📋</span>
              <div>
                <strong>Historial de servicios</strong>
                <p>Consulta todos tus servicios anteriores</p>
              </div>
            </li>
            <li className="login__benefit-item">
              <span className="login__benefit-icon">🎯</span>
              <div>
                <strong>Experiencia personalizada</strong>
                <p>Recomendaciones basadas en tus preferencias</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default Login;