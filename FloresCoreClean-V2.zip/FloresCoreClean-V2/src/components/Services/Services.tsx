import React, { useState } from 'react';
import Button from '../Button';
import { SERVICES_DATA } from '../../utils/mockData';
import './Services.less';

export interface ServicesProps {
  className?: string;
  onAddToCart?: (item: { id: string; type: 'product' | 'service'; name: string; price: number; image: string; selectedVariant?: string }) => void;
}

const serviceCategories = [
  { id: 'all', name: 'Todos los Servicios', icon: '🏠' },
  { id: 'furniture', name: 'Muebles', icon: '🛋️' },
  { id: 'carpets', name: 'Alfombras', icon: '🪣' },
  { id: 'home', name: 'Hogar', icon: '🏡' },
  { id: 'automotive', name: 'Automotriz', icon: '🚗' },
  { id: 'packages', name: 'Paquetes', icon: '📦' },
  { id: 'maintenance', name: 'Mantenimiento', icon: '🔧' },
  { id: 'express', name: 'Express', icon: '⚡' },
  { id: 'specialized', name: 'Especializado', icon: '🦠' },
];

const Services: React.FC<ServicesProps> = ({ className = '', onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState<'price' | 'rating' | 'reviews' | 'name'>('price');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  // Filter services by category and search term
  const filteredServices = SERVICES_DATA.filter(service => {
    const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
    const matchesSearch = service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         service.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Sort services
  const sortedServices = [...filteredServices].sort((a, b) => {
    let aValue: number | string;
    let bValue: number | string;

    switch (sortBy) {
      case 'price':
        aValue = a.startingPrice;
        bValue = b.startingPrice;
        break;
      case 'rating':
        aValue = a.rating;
        bValue = b.rating;
        break;
      case 'reviews':
        aValue = a.reviews;
        bValue = b.reviews;
        break;
      case 'name':
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
        break;
      default:
        return 0;
    }

    if (sortOrder === 'asc') {
      return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
    } else {
      return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
    }
  });

  // Pagination logic
  const totalItems = sortedServices.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedServices = sortedServices.slice(startIndex, endIndex);
  
  // Reset to page 1 when filters change
  const resetPagination = () => {
    setCurrentPage(1);
  };

  // Update pagination when search or category changes
  React.useEffect(() => {
    resetPagination();
  }, [searchTerm, selectedCategory]);

  const formatPrice = (price: number) => {
    return `S/. ${price.toFixed(2)}`;
  };

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`} className="star full">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  return (
    <div className={`services ${className}`}>
      <div className="services__container">
        {/* Header */}
        <div className="services__header">
          <div className="services__title-section">
            <h1 className="services__title">Nuestros Servicios</h1>
            <p className="services__subtitle">
              Servicios profesionales de limpieza con precios desde y duración estimada
            </p>
          </div>
          
          <div className="services__stats">
            <div className="services__stat">
              <span className="services__stat-number">{SERVICES_DATA.length}</span>
              <span className="services__stat-label">Servicios Disponibles</span>
            </div>
            <div className="services__stat">
              <span className="services__stat-number">{SERVICES_DATA.filter(s => s.onSale).length}</span>
              <span className="services__stat-label">En Oferta</span>
            </div>
            <div className="services__stat">
              <span className="services__stat-number">4.8</span>
              <span className="services__stat-label">Calificación Promedio</span>
            </div>
          </div>
        </div>

        {/* Main Layout: Sidebar + Content */}
        <div className="services__layout">
          {/* Sidebar with Filters */}
          <aside className="services__sidebar">
            <div className="services__sidebar-section">
              <h3 className="services__sidebar-title">Buscar</h3>
              <div className="services__search">
                <input
                  type="text"
                  placeholder="Buscar servicios..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="services__search-input"
                />
                <span className="services__search-icon">🔍</span>
              </div>
              {searchTerm && (
                <button
                  className="services__clear-search"
                  onClick={() => setSearchTerm('')}
                >
                  Limpiar búsqueda
                </button>
              )}
            </div>

            <div className="services__sidebar-section">
              <h3 className="services__sidebar-title">Categorías</h3>
              <div className="services__categories">
                {serviceCategories.map(category => (
                  <button
                    key={category.id}
                    className={`services__category ${selectedCategory === category.id ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="services__category-icon">{category.icon}</span>
                    <span className="services__category-name">{category.name}</span>
                    <span className="services__category-count">
                      ({selectedCategory === 'all' 
                        ? SERVICES_DATA.filter(s => category.id === 'all' || s.category === category.id).length
                        : category.id === 'all' 
                          ? SERVICES_DATA.length 
                          : SERVICES_DATA.filter(s => s.category === category.id).length})
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="services__sidebar-section">
              <h3 className="services__sidebar-title">Filtros</h3>
              <div className="services__filter-group">
                <label className="services__filter-label">Disponibilidad</label>
                <div className="services__checkbox-group">
                  <label className="services__checkbox">
                    <input type="checkbox" defaultChecked />
                    <span>Disponibles ahora</span>
                  </label>
                  <label className="services__checkbox">
                    <input type="checkbox" />
                    <span>Próximamente</span>
                  </label>
                </div>
              </div>

              <div className="services__filter-group">
                <label className="services__filter-label">Ofertas</label>
                <div className="services__checkbox-group">
                  <label className="services__checkbox">
                    <input type="checkbox" />
                    <span>Solo ofertas</span>
                  </label>
                  <label className="services__checkbox">
                    <input type="checkbox" />
                    <span>Descuentos especiales</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="services__main">
            {/* Top Bar with Results and Sorting */}
            <div className="services__top-bar">
              <div className="services__results-info">
                <span className="services__results-count">
                  {totalPages > 1 
                    ? `Mostrando ${startIndex + 1} al ${Math.min(endIndex, totalItems)} de ${totalItems} servicio${totalItems !== 1 ? 's' : ''}`
                    : `Mostrando ${totalItems} servicio${totalItems !== 1 ? 's' : ''}`
                  }
                </span>
              </div>
              
              <div className="services__sort">
                <label className="services__sort-label">Ordenar por:</label>
                <select
                  value={`${sortBy}-${sortOrder}`}
                  onChange={(e) => {
                    const [field, order] = e.target.value.split('-') as [typeof sortBy, typeof sortOrder];
                    setSortBy(field);
                    setSortOrder(order);
                  }}
                  className="services__sort-select"
                >
                  <option value="price-asc">Precio: Menor a Mayor</option>
                  <option value="price-desc">Precio: Mayor a Menor</option>
                  <option value="rating-desc">Mejor Calificados</option>
                  <option value="reviews-desc">Más Reseñas</option>
                  <option value="name-asc">Nombre: A-Z</option>
                  <option value="name-desc">Nombre: Z-A</option>
                </select>
              </div>
            </div>

            {/* Services Grid */}
            <div className="services__grid">
          {paginatedServices.map(service => (
            <div key={service.id} className="services__card">
              {service.badge && (
                <div className={`services__badge services__badge--${service.badge.toLowerCase()}`}>
                  {service.badge}
                </div>
              )}

              <div className="services__card-header">
                <div className="services__image">{service.image}</div>
                <div className="services__card-info">
                  <h3 className="services__name">{service.name}</h3>
                  <div className="services__category-badge">
                    {serviceCategories.find(c => c.id === service.category)?.name || 'Servicio'}
                  </div>
                </div>
              </div>

              <div className="services__pricing">
                <div className="services__price-section">
                  <div className="services__price-main">
                    {service.originalStartingPrice && service.onSale && (
                      <span className="services__price-original">
                        Desde {formatPrice(service.originalStartingPrice)}
                      </span>
                    )}
                    <span className="services__price-current">
                      Desde {formatPrice(service.startingPrice)}
                    </span>
                  </div>
                  <div className="services__duration">
                    <span className="services__duration-icon">⏱️</span>
                    <span className="services__duration-text">{service.estimatedDuration}</span>
                  </div>
                </div>

                {service.onSale && service.originalStartingPrice && (
                  <div className="services__savings">
                    Ahorras {formatPrice(service.originalStartingPrice - service.startingPrice)}
                  </div>
                )}
              </div>

              <div className="services__description">
                <p>{service.description}</p>
              </div>

              <div className="services__features">
                <ul className="services__features-list">
                  {service.features.slice(0, 3).map((feature, index) => (
                    <li key={index} className="services__feature">
                      <span className="services__feature-icon">✓</span>
                      {feature}
                    </li>
                  ))}
                  {service.features.length > 3 && (
                    <li className="services__feature services__feature--more">
                      +{service.features.length - 3} más
                    </li>
                  )}
                </ul>
              </div>

              <div className="services__rating">
                <div className="services__stars">
                  {renderStars(service.rating)}
                </div>
                <span className="services__rating-text">
                  {service.rating} ({service.reviews} reseñas)
                </span>
              </div>

              <div className="services__actions">
                <Button 
                  variant="primary" 
                  className="services__book-btn"
                  onClick={() => {
                    if (onAddToCart) {
                      onAddToCart({
                        id: service.id,
                        type: 'service',
                        name: service.name,
                        price: service.startingPrice,
                        image: service.image
                      });
                      alert(`${service.name} agregado al carrito!`);
                    }
                  }}
                >
                  Agregar al Carrito
                </Button>
                <Button variant="outline" size="small" className="services__info-btn">
                  Más Info
                </Button>
              </div>

              {!service.available && (
                <div className="services__unavailable">
                  <span>Temporalmente no disponible</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="services__pagination">
            <button 
              className="services__page-btn"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              ← Anterior
            </button>
            
            <div className="services__page-info">
              <span>Página {currentPage} de {totalPages}</span>
            </div>
            
            <div className="services__page-numbers">
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(page => {
                  // Show first page, last page, current page, and pages around current
                  return page === 1 || 
                         page === totalPages || 
                         (page >= currentPage - 1 && page <= currentPage + 1);
                })
                .map((page, index, array) => (
                  <React.Fragment key={page}>
                    {index > 0 && array[index - 1] < page - 1 && <span className="services__page-dots">...</span>}
                    <button
                      className={`services__page-number ${currentPage === page ? 'active' : ''}`}
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </button>
                  </React.Fragment>
                ))
              }
            </div>
            
            <button 
              className="services__page-btn"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Siguiente →
            </button>
          </div>
        )}

        {totalItems === 0 && (
          <div className="services__empty-state">
            <div className="services__empty-icon">🔍</div>
            <h3 className="services__empty-title">No se encontraron servicios</h3>
            <p className="services__empty-text">
              {searchTerm 
                ? `No hay servicios que coincidan con "${searchTerm}"`
                : 'No hay servicios en esta categoría'
              }
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
            >
              Ver todos los servicios
            </Button>
          </div>
        )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Services;