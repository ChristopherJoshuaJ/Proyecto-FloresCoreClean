import React, { useState } from 'react';
import Button from '../Button';
import type { User } from '../../utils/mockData';
import { 
  getAllReservations, 
  getAllClients, 
  getAllStaff, 
  getAdminServices, 
  getAdminProducts,
  getAdminStats,
  type Reservation,
  type Client,
  type Staff,
  type AdminService,
  type AdminProduct,
  type AdminStats
} from '../../utils/mockData';
import './AdminDashboard.less';

export interface AdminDashboardProps {
  user: User;
  onLogout: () => void;
  onNavigation: (page: string, tab?: string) => void;
  currentTheme: string;
  onThemeChange: (theme: string) => void;
  initialTab?: 'dashboard' | 'reservations' | 'clients' | 'staff' | 'services' | 'products' | 'reports' | 'settings';
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({
  user,
  onLogout,
  onNavigation,
  currentTheme,
  onThemeChange,
  initialTab = 'dashboard'
}) => {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'reservations' | 'clients' | 'staff' | 'services' | 'products' | 'reports' | 'settings'>(initialTab);
  const [showServiceModal, setShowServiceModal] = useState(false);
  const [editingService, setEditingService] = useState<AdminService | null>(null);

  // Get admin data
  const reservations = getAllReservations();
  const clients = getAllClients();
  const staff = getAllStaff();
  const services = getAdminServices();
  const products = getAdminProducts();
  const stats = getAdminStats();

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'completed':
      case 'finalizado':
      case 'activo': return '#5aaf78';
      case 'in-progress':
      case 'en-camino': return '#4782c9';
      case 'pending':
      case 'pendiente': return '#fb923c';
      case 'cancelled':
      case 'inactivo': return '#ff0000';
      default: return '#6b7280';
    }
  };

  const getStatusText = (status: string): string => {
    switch (status) {
      case 'completed': return 'Finalizado';
      case 'in-progress': return 'En Camino';
      case 'pending': return 'Pendiente';
      case 'cancelled': return 'Cancelado';
      case 'finalizado': return 'Finalizado';
      case 'en-camino': return 'En Camino';
      case 'pendiente': return 'Pendiente';
      case 'activo': return 'Activo';
      case 'inactivo': return 'Inactivo';
      default: return status;
    }
  };

  const handleNewService = () => {
    setEditingService(null);
    setShowServiceModal(true);
  };

  const handleEditService = (service: AdminService) => {
    setEditingService(service);
    setShowServiceModal(true);
  };

  const handleCloseServiceModal = () => {
    setShowServiceModal(false);
    setEditingService(null);
  };

  const handleDeleteService = (id: string) => {
    if (confirm('¿Está seguro de que desea eliminar este servicio?')) {
      console.log('Deleting service:', id);
      // Implementation would go here
    }
  };

  const renderDashboard = () => (
    <div className="admin-dashboard__overview">
      <div className="admin-dashboard__welcome">
        <div className="admin-dashboard__welcome-content">
          <div className="admin-dashboard__avatar">{user.avatar}</div>
          <div>
            <h2 className="admin-dashboard__welcome-title">
              ¡Bienvenido, {user.firstName}!
            </h2>
            <p className="admin-dashboard__welcome-subtitle">
              Panel de Administración
            </p>
          </div>
        </div>
        <div className="admin-dashboard__quick-actions">
          <Button variant="primary" onClick={() => setActiveTab('reservations')}>
            Gestionar Reservas
          </Button>
          <Button variant="outline" onClick={() => setActiveTab('services')}>
            Administrar Servicios
          </Button>
        </div>
      </div>

      <div className="admin-dashboard__stats">
        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">📋</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">{stats.reservationsThisMonth}</h3>
            <p className="admin-dashboard__stat-label">Reservas este mes</p>
          </div>
        </div>
        
        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">💰</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">S/ {stats.revenue.toLocaleString()}</h3>
            <p className="admin-dashboard__stat-label">Ingresos Generados</p>
          </div>
        </div>

        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">👥</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">{stats.newClients}</h3>
            <p className="admin-dashboard__stat-label">Clientes Nuevos</p>
          </div>
        </div>

        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">⭐</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">{stats.averageRating}/5</h3>
            <p className="admin-dashboard__stat-label">Satisfacción Promedio</p>
          </div>
        </div>
      </div>

      <div className="admin-dashboard__charts">
        <div className="admin-dashboard__chart-card">
          <h3>📈 Reservas por Mes</h3>
          <div className="admin-dashboard__chart-placeholder">
            <div className="admin-dashboard__chart-visual">
              <div className="admin-dashboard__chart-bars">
                <div className="admin-dashboard__chart-bar" style={{ height: '60%' }}>
                  <span className="admin-dashboard__chart-value">45</span>
                </div>
                <div className="admin-dashboard__chart-bar" style={{ height: '80%' }}>
                  <span className="admin-dashboard__chart-value">68</span>
                </div>
                <div className="admin-dashboard__chart-bar" style={{ height: '100%' }}>
                  <span className="admin-dashboard__chart-value">124</span>
                </div>
                <div className="admin-dashboard__chart-bar" style={{ height: '75%' }}>
                  <span className="admin-dashboard__chart-value">89</span>
                </div>
              </div>
              <div className="admin-dashboard__chart-labels">
                <span>Jul</span>
                <span>Ago</span>
                <span>Sep</span>
                <span>Oct</span>
              </div>
            </div>
          </div>
        </div>
        <div className="admin-dashboard__chart-card">
          <h3>🏆 Servicios Más Solicitados</h3>
          <div className="admin-dashboard__chart-placeholder">
            <div className="admin-dashboard__service-stats">
              <div className="admin-dashboard__service-stat">
                <span className="admin-dashboard__service-icon">🛋️</span>
                <span className="admin-dashboard__service-name">Limpieza de Muebles</span>
                <span className="admin-dashboard__service-count">45</span>
              </div>
              <div className="admin-dashboard__service-stat">
                <span className="admin-dashboard__service-icon">🪣</span>
                <span className="admin-dashboard__service-name">Limpieza de Alfombras</span>
                <span className="admin-dashboard__service-count">38</span>
              </div>
              <div className="admin-dashboard__service-stat">
                <span className="admin-dashboard__service-icon">🛏️</span>
                <span className="admin-dashboard__service-name">Limpieza de Colchones</span>
                <span className="admin-dashboard__service-count">32</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderReservations = () => (
    <div className="admin-dashboard__reservations">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Gestión de Reservas</h3>
        <Button variant="primary">+ Nueva Reserva</Button>
      </div>
      
      <div className="admin-dashboard__filters">
        <input type="date" placeholder="Fecha" className="admin-dashboard__filter-input" />
        <select className="admin-dashboard__filter-select">
          <option>Todos los estados</option>
          <option>Pendiente</option>
          <option>En camino</option>
          <option>Finalizado</option>
        </select>
        <input type="text" placeholder="Buscar por cliente..." className="admin-dashboard__filter-input" />
      </div>

      <div className="admin-dashboard__table-container">
        <table className="admin-dashboard__table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Cliente</th>
              <th>Servicio</th>
              <th>Fecha y Hora</th>
              <th>Estado</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {reservations.map(reservation => (
              <tr key={reservation.id}>
                <td>{reservation.id}</td>
                <td>{reservation.clientName}</td>
                <td>{reservation.service}</td>
                <td>{new Date(reservation.dateTime).toLocaleString('es-ES')}</td>
                <td>
                  <span 
                    className="admin-dashboard__status-badge"
                    style={{ backgroundColor: getStatusColor(reservation.status) }}
                  >
                    {getStatusText(reservation.status)}
                  </span>
                </td>
                <td className="admin-dashboard__actions">
                  <button title="Editar" className="admin-dashboard__action-btn">
                    📝
                  </button>
                  <button title="Reasignar" className="admin-dashboard__action-btn">
                    👥
                  </button>
                  <button title="Cancelar" className="admin-dashboard__action-btn admin-dashboard__action-btn--danger">
                    ❌
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderClients = () => (
    <div className="admin-dashboard__clients">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Lista de Clientes</h3>
        <div className="admin-dashboard__export-buttons">
          <Button variant="outline" size="small">Exportar CSV</Button>
          <Button variant="outline" size="small">Exportar PDF</Button>
        </div>
      </div>

      <div className="admin-dashboard__table-container">
        <table className="admin-dashboard__table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Correo</th>
              <th>Teléfono</th>
              <th>Historial</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {clients.map(client => (
              <tr key={client.id}>
                <td>{client.id}</td>
                <td>{client.name}</td>
                <td>{client.email}</td>
                <td>{client.phone}</td>
                <td>{client.bookingHistory} reservas</td>
                <td className="admin-dashboard__actions">
                  <button title="Ver Detalles" className="admin-dashboard__action-btn">
                    👁️
                  </button>
                  <button title="Editar" className="admin-dashboard__action-btn">
                    📝
                  </button>
                  <button title="Eliminar" className="admin-dashboard__action-btn admin-dashboard__action-btn--danger">
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderStaff = () => (
    <div className="admin-dashboard__staff">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Equipo de Técnicos</h3>
        <Button variant="outline">Ver Calendario</Button>
      </div>

      <div className="admin-dashboard__staff-grid">
        {staff.map(member => (
          <div key={member.id} className={`admin-dashboard__staff-card ${member.status}`}>
            <div className="admin-dashboard__staff-header">
              <div className="admin-dashboard__staff-avatar">{member.avatar}</div>
              <div className="admin-dashboard__staff-status-indicator">
                {member.status === 'available' ? '🟢' : '🔴'}
              </div>
            </div>
            <h4 className="admin-dashboard__staff-name">{member.name}</h4>
            <p className="admin-dashboard__staff-status">
              {member.status === 'available' ? '✅ Disponible' : '⏰ Ocupado'}
            </p>
            {member.currentAssignment && (
              <div className="admin-dashboard__staff-assignment">
                <span className="admin-dashboard__assignment-label">Asignado:</span>
                <span className="admin-dashboard__assignment-text">{member.currentAssignment}</span>
              </div>
            )}
            <div className="admin-dashboard__staff-stats">
              <div className="admin-dashboard__staff-stat">
                <span className="admin-dashboard__stat-icon">📋</span>
                <span className="admin-dashboard__stat-value">{member.completedJobs}</span>
                <span className="admin-dashboard__stat-label">Trabajos</span>
              </div>
              <div className="admin-dashboard__staff-stat">
                <span className="admin-dashboard__stat-icon">⭐</span>
                <span className="admin-dashboard__stat-value">{member.rating}</span>
                <span className="admin-dashboard__stat-label">Rating</span>
              </div>
            </div>
            <Button 
              variant={member.status === 'available' ? 'primary' : 'outline'}
              size="small"
              disabled={member.status !== 'available'}
            >
              {member.status === 'available' ? '📝 Asignar Servicio' : '⏱️ No Disponible'}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );

  const renderServices = () => (
    <div className="admin-dashboard__services">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Gestión de Servicios</h3>
        <Button variant="primary" onClick={handleNewService}>
          <i className="fas fa-plus"></i> Nuevo Servicio
        </Button>
      </div>

      <div className="admin-dashboard__filters">
        <input 
          type="text" 
          placeholder="🔍 Buscar servicio..." 
          className="admin-dashboard__filter-input"
        />
        <select className="admin-dashboard__filter-select">
          <option value="">Todas las categorías</option>
          <option value="limpieza">Limpieza</option>
          <option value="mantenimiento">Mantenimiento</option>
          <option value="especializado">Especializado</option>
        </select>
        <select className="admin-dashboard__filter-select">
          <option value="">Todos los estados</option>
          <option value="activo">Activo</option>
          <option value="inactivo">Inactivo</option>
        </select>
      </div>

      <div className="admin-dashboard__services-grid">
        {services.map(service => (
          <div key={service.id} className={`admin-dashboard__service-card ${service.status}`}>
            <div className="admin-dashboard__service-header">
              <div className="admin-dashboard__service-icon">{service.icon}</div>
              <div className="admin-dashboard__service-actions">
                <button 
                  className="admin-dashboard__action-btn"
                  onClick={() => handleEditService(service)}
                  title="Editar"
                >
                  📝
                </button>
                <button 
                  className="admin-dashboard__action-btn admin-dashboard__action-btn--danger"
                  onClick={() => handleDeleteService(service.id)}
                  title="Eliminar"
                >
                  🗑️
                </button>
              </div>
            </div>
            <h4 className="admin-dashboard__service-name">{service.name}</h4>
            <p className="admin-dashboard__service-desc">{service.description}</p>
            <div className="admin-dashboard__service-info">
              <div className="admin-dashboard__service-info-item">
                <span className="admin-dashboard__service-label">Precio:</span>
                <span className="admin-dashboard__service-value">S/ {service.price.toFixed(2)}</span>
              </div>
              <div className="admin-dashboard__service-info-item">
                <span className="admin-dashboard__service-label">Duración:</span>
                <span className="admin-dashboard__service-value">{service.duration}</span>
              </div>
              <div className="admin-dashboard__service-info-item">
                <span className="admin-dashboard__service-label">Reservas:</span>
                <span className="admin-dashboard__service-value">{service.bookings} este mes</span>
              </div>
            </div>
            <div className="admin-dashboard__service-status">
              <span 
                className="admin-dashboard__status-badge"
                style={{ backgroundColor: getStatusColor(service.status) }}
              >
                {getStatusText(service.status)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderProducts = () => (
    <div className="admin-dashboard__products">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Gestión de Productos</h3>
        <Button variant="primary">+ Nuevo Producto</Button>
      </div>

      <div className="admin-dashboard__filters">
        <input type="text" placeholder="Buscar producto..." className="admin-dashboard__filter-input" />
        <select className="admin-dashboard__filter-select">
          <option>Todas las categorías</option>
          <option>Limpieza</option>
          <option>Protectores</option>
          <option>Accesorios</option>
        </select>
        <select className="admin-dashboard__filter-select">
          <option>Todo el stock</option>
          <option>En stock</option>
          <option>Stock bajo</option>
        </select>
      </div>

      <div className="admin-dashboard__table-container">
        <table className="admin-dashboard__table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Nombre</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Stock</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {products.map(product => (
              <tr key={product.id}>
                <td>{product.id}</td>
                <td>{product.name}</td>
                <td>{product.category}</td>
                <td>S/ {product.price.toFixed(2)}</td>
                <td className={product.stock < 10 ? 'admin-dashboard__low-stock' : ''}>
                  {product.stock}
                </td>
                <td className="admin-dashboard__actions">
                  <button title="Editar" className="admin-dashboard__action-btn">
                    📝
                  </button>
                  <button title="Eliminar" className="admin-dashboard__action-btn admin-dashboard__action-btn--danger">
                    🗑️
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );

  const renderReports = () => (
    <div className="admin-dashboard__reports">
      <div className="admin-dashboard__section-header">
        <h3 className="admin-dashboard__section-title">Reportes y Analytics</h3>
        <div className="admin-dashboard__export-buttons">
          <Button variant="outline" size="small">Exportar PDF</Button>
          <Button variant="outline" size="small">Exportar Excel</Button>
        </div>
      </div>

      <div className="admin-dashboard__stats">
        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">⏱️</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">45 min</h3>
            <p className="admin-dashboard__stat-label">Tiempo promedio</p>
          </div>
        </div>
        
        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">❌</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">5%</h3>
            <p className="admin-dashboard__stat-label">Tasa de cancelaciones</p>
          </div>
        </div>

        <div className="admin-dashboard__stat-card">
          <div className="admin-dashboard__stat-icon">🔄</div>
          <div className="admin-dashboard__stat-content">
            <h3 className="admin-dashboard__stat-number">68%</h3>
            <p className="admin-dashboard__stat-label">Clientes recurrentes</p>
          </div>
        </div>
      </div>

      <div className="admin-dashboard__charts">
        <div className="admin-dashboard__chart-card">
          <h3>💰 Ingresos por Mes</h3>
          <div className="admin-dashboard__chart-placeholder">
            <div className="admin-dashboard__revenue-visual">
              <div className="admin-dashboard__revenue-chart">
                <div className="admin-dashboard__revenue-line">
                  <div className="admin-dashboard__revenue-point" style={{ left: '20%', bottom: '40%' }}>
                    <span className="admin-dashboard__revenue-tooltip">S/ 12,500</span>
                  </div>
                  <div className="admin-dashboard__revenue-point" style={{ left: '40%', bottom: '60%' }}>
                    <span className="admin-dashboard__revenue-tooltip">S/ 15,200</span>
                  </div>
                  <div className="admin-dashboard__revenue-point" style={{ left: '60%', bottom: '85%' }}>
                    <span className="admin-dashboard__revenue-tooltip">S/ 18,500</span>
                  </div>
                  <div className="admin-dashboard__revenue-point" style={{ left: '80%', bottom: '70%' }}>
                    <span className="admin-dashboard__revenue-tooltip">S/ 16,800</span>
                  </div>
                </div>
              </div>
              <div className="admin-dashboard__revenue-labels">
                <span>Jul</span>
                <span>Ago</span>
                <span>Sep</span>
                <span>Oct</span>
              </div>
            </div>
          </div>
        </div>
        <div className="admin-dashboard__chart-card">
          <h3>⭐ Satisfacción del Cliente</h3>
          <div className="admin-dashboard__chart-placeholder">
            <div className="admin-dashboard__satisfaction-visual">
              <div className="admin-dashboard__satisfaction-circle">
                <div className="admin-dashboard__satisfaction-percentage">98%</div>
                <div className="admin-dashboard__satisfaction-label">Satisfacción</div>
              </div>
              <div className="admin-dashboard__satisfaction-stats">
                <div className="admin-dashboard__satisfaction-item">
                  <span className="admin-dashboard__satisfaction-stars">⭐⭐⭐⭐⭐</span>
                  <span className="admin-dashboard__satisfaction-count">245</span>
                </div>
                <div className="admin-dashboard__satisfaction-item">
                  <span className="admin-dashboard__satisfaction-stars">⭐⭐⭐⭐</span>
                  <span className="admin-dashboard__satisfaction-count">12</span>
                </div>
                <div className="admin-dashboard__satisfaction-item">
                  <span className="admin-dashboard__satisfaction-stars">⭐⭐⭐</span>
                  <span className="admin-dashboard__satisfaction-count">3</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSettings = () => {
    const themes = [
      { value: 'green', label: 'Verde', color: '#5aaf78' },
      { value: 'blue', label: 'Azul', color: '#4782c9' },
      { value: 'red', label: 'Rojo', color: '#ff0000' },
      { value: 'purple', label: 'Morado', color: '#2f2c79' },
      { value: 'orange', label: 'Naranja', color: '#ff4711' },
    ];

    return (
      <div className="admin-dashboard__settings">
        <h3 className="admin-dashboard__section-title">Configuración del Sistema</h3>
        
        <div className="admin-dashboard__config-grid">
          <div className="admin-dashboard__config-card">
            <h4><i className="fas fa-users-cog"></i> Roles y Permisos</h4>
            <div className="admin-dashboard__table-container">
              <table className="admin-dashboard__table">
                <thead>
                  <tr>
                    <th>Usuario</th>
                    <th>Rol</th>
                    <th>Permisos</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>admin@empresa.com</td>
                    <td>Administrador</td>
                    <td>Todos los permisos</td>
                  </tr>
                  <tr>
                    <td>supervisor@empresa.com</td>
                    <td>Supervisor</td>
                    <td>Gestión de reservas y clientes</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          <div className="admin-dashboard__config-card">
            <h4><i className="fas fa-building"></i> Datos de la Empresa</h4>
            <form className="admin-dashboard__company-form">
              <div className="admin-dashboard__form-group">
                <label>Nombre de la empresa</label>
                <input type="text" defaultValue="FloresCore Clean" />
              </div>
              <div className="admin-dashboard__form-group">
                <label>Dirección</label>
                <input type="text" defaultValue="Av. Ejemplo 123, Lima" />
              </div>
              <div className="admin-dashboard__form-group">
                <label>Horarios de atención</label>
                <input type="text" defaultValue="Lunes a Sábado 8:00 - 18:00" />
              </div>
              <Button variant="primary">Guardar Cambios</Button>
            </form>
          </div>

          <div className="admin-dashboard__config-card">
            <h4><i className="fas fa-palette"></i> Apariencia</h4>
            <div className="admin-dashboard__theme-selector">
              <label className="admin-dashboard__field-label">Tema de color</label>
              <div className="admin-dashboard__theme-options">
                {themes.map((theme) => (
                  <button
                    key={theme.value}
                    className={`admin-dashboard__theme-option ${currentTheme === theme.value ? 'active' : ''}`}
                    onClick={() => onThemeChange(theme.value)}
                    style={{ '--theme-color': theme.color } as React.CSSProperties}
                    title={`Cambiar a tema ${theme.label}`}
                  >
                    <div className="admin-dashboard__theme-color" style={{ backgroundColor: theme.color }}></div>
                    <span className="admin-dashboard__theme-label">{theme.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const renderServiceModal = () => {
    if (!showServiceModal) return null;

    return (
      <div className="admin-dashboard__modal">
        <div className="admin-dashboard__modal-content">
          <div className="admin-dashboard__modal-header">
            <h3>{editingService ? 'Editar Servicio' : 'Nuevo Servicio'}</h3>
            <button 
              className="admin-dashboard__modal-close"
              onClick={handleCloseServiceModal}
            >
              ✖
            </button>
          </div>
          <form className="admin-dashboard__modal-form">
            <div className="admin-dashboard__form-group">
              <label>Nombre del Servicio</label>
              <input 
                type="text" 
                defaultValue={editingService?.name || ''} 
                required 
              />
            </div>
            <div className="admin-dashboard__form-group">
              <label>Descripción</label>
              <textarea 
                rows={3} 
                defaultValue={editingService?.description || ''} 
                required
              />
            </div>
            <div className="admin-dashboard__form-row">
              <div className="admin-dashboard__form-group">
                <label>Precio (S/)</label>
                <input 
                  type="number" 
                  step="0.01" 
                  defaultValue={editingService?.price || ''} 
                  required 
                />
              </div>
              <div className="admin-dashboard__form-group">
                <label>Duración</label>
                <input 
                  type="text" 
                  defaultValue={editingService?.duration || ''} 
                  required 
                />
              </div>
            </div>
            <div className="admin-dashboard__form-row">
              <div className="admin-dashboard__form-group">
                <label>Categoría</label>
                <select defaultValue={editingService?.category || 'limpieza'} required>
                  <option value="limpieza">Limpieza</option>
                  <option value="mantenimiento">Mantenimiento</option>
                  <option value="especializado">Especializado</option>
                </select>
              </div>
              <div className="admin-dashboard__form-group">
                <label>Estado</label>
                <select defaultValue={editingService?.status || 'activo'} required>
                  <option value="activo">Activo</option>
                  <option value="inactivo">Inactivo</option>
                </select>
              </div>
            </div>
            <div className="admin-dashboard__modal-actions">
              <Button variant="outline" onClick={handleCloseServiceModal}>
                Cancelar
              </Button>
              <Button variant="primary">
                {editingService ? 'Actualizar' : 'Crear'} Servicio
              </Button>
            </div>
          </form>
        </div>
      </div>
    );
  };

  return (
    <div className="admin-dashboard">
      <div className="admin-dashboard__container">
        <div className="admin-dashboard__sidebar">
          <div className="admin-dashboard__logo">
            <div className="admin-dashboard__logo-text">
              <h3>FloresCore</h3>
              <span>Clean</span>
            </div>
          </div>
          
          <nav className="admin-dashboard__nav">
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'dashboard' ? 'active' : ''}`}
              onClick={() => setActiveTab('dashboard')}
            >
              🏠 <span>Inicio</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'reservations' ? 'active' : ''}`}
              onClick={() => setActiveTab('reservations')}
            >
              📅 <span>Reservas</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'clients' ? 'active' : ''}`}
              onClick={() => setActiveTab('clients')}
            >
              👥 <span>Clientes</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'staff' ? 'active' : ''}`}
              onClick={() => setActiveTab('staff')}
            >
              👨‍💼 <span>Personal</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'services' ? 'active' : ''}`}
              onClick={() => setActiveTab('services')}
            >
              🔧 <span>Servicios</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'products' ? 'active' : ''}`}
              onClick={() => setActiveTab('products')}
            >
              📦 <span>Productos</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'reports' ? 'active' : ''}`}
              onClick={() => setActiveTab('reports')}
            >
              📊 <span>Reportes</span>
            </button>
            <button
              className={`admin-dashboard__nav-item ${activeTab === 'settings' ? 'active' : ''}`}
              onClick={() => setActiveTab('settings')}
            >
              ⚙️ <span>Configuración</span>
            </button>
          </nav>

          <div className="admin-dashboard__sidebar-footer">
            <Button variant="outline" onClick={() => onNavigation('home')}>
              🏠 Ir al Inicio
            </Button>
            <Button variant="outline" onClick={onLogout} className="admin-dashboard__logout-btn">
              🚪 Cerrar Sesión
            </Button>
          </div>
        </div>

        <div className="admin-dashboard__content">
          {activeTab === 'dashboard' && renderDashboard()}
          {activeTab === 'reservations' && renderReservations()}
          {activeTab === 'clients' && renderClients()}
          {activeTab === 'staff' && renderStaff()}
          {activeTab === 'services' && renderServices()}
          {activeTab === 'products' && renderProducts()}
          {activeTab === 'reports' && renderReports()}
          {activeTab === 'settings' && renderSettings()}
        </div>
      </div>
      
      {renderServiceModal()}
    </div>
  );
};

export default AdminDashboard;