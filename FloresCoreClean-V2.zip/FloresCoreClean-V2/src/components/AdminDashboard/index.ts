export { default } from './AdminDashboard';
export type { AdminDashboardProps } from './AdminDashboard';