export { default } from './Products';
export type { ProductsProps, Product } from './Products';