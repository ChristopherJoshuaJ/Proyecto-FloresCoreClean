import React, { useState, useEffect } from 'react';
import Button from '../Button';
import './Products.less';

export interface Product {
  id: string;
  name: string;
  category: string;
  price: number;
  originalPrice?: number;
  description: string;
  features: string[];
  image: string;
  badge?: string;
  inStock: boolean;
  rating: number;
  reviews: number;
  onSale?: boolean;
}

export interface ProductsProps {
  className?: string;
  onAddToCart?: (item: { id: string; type: 'product' | 'service'; name: string; price: number; image: string; selectedVariant?: string }) => void;
}

const productCategories = [
  { id: 'all', name: 'Todos los Productos', icon: '📋' },
  { id: 'protectors', name: 'Protectores', icon: '🛡️' },
  { id: 'cleaners', name: 'Limpiadores', icon: '🧴' },
  { id: 'deodorizers', name: 'Desodorantes', icon: '🌿' },
  { id: 'kits', name: 'Kits Completos', icon: '📦' },
  { id: 'tools', name: 'Herramientas', icon: '🔧' },
  { id: 'accessories', name: 'Accesorios', icon: '🧽' },
];

const products: Product[] = [
  // Protectores
  {
    id: 'prot-001',
    name: 'ScotchGard Pro Shield',
    category: 'protectors',
    price: 89.90,
    originalPrice: 120.00,
    description: 'Protector antimanchas profesional de última generación. Ideal para muebles de tela y cuero.',
    features: ['Protección antimanchas', 'Para tela y cuero', 'Fórmula profesional', 'Duración 8 meses'],
    image: '🛡️',
    badge: 'OFERTA',
    inStock: true,
    rating: 5.0,
    reviews: 127
  },
  {
    id: 'prot-002',
    name: 'Protector Antimanchas Profesional',
    category: 'protectors',
    price: 55.90,
    originalPrice: 69.90,
    description: 'Protección invisible y duradera contra manchas líquidas y sólidas. Fórmula profesional que mantiene la transpirabilidad del tejido.',
    features: ['Protección 6 meses', 'Invisible y transpirable', 'Repele líquidos', 'No altera textura'],
    image: '🛡️',
    badge: 'BESTSELLER',
    inStock: true,
    rating: 4.8,
    reviews: 98
  },
  {
    id: 'prot-003',
    name: 'Protector UV Plus',
    category: 'protectors',
    price: 48.50,
    description: 'Protección contra rayos UV y decoloración. Ideal para muebles expuestos al sol.',
    features: ['Protección UV', 'Anti-decoloración', 'Larga duración', 'Fácil aplicación'],
    image: '☀️',
    inStock: true,
    rating: 4.6,
    reviews: 89
  },
  {
    id: 'prot-004',
    name: 'Protector Infantil Seguro',
    category: 'protectors',
    price: 42.90,
    description: 'Fórmula especial libre de químicos agresivos, segura para niños y mascotas.',
    features: ['100% Seguro', 'Sin químicos tóxicos', 'Aprobado pediatría', 'Protección efectiva'],
    image: '👶',
    badge: 'ECO FRIENDLY',
    inStock: true,
    rating: 4.9,
    reviews: 156
  },

  // Limpiadores
  {
    id: 'clean-001',
    name: 'UltraClean Enzyme',
    category: 'cleaners',
    price: 75.00,
    description: 'Limpiador enzimático que elimina manchas difíciles y olores persistentes de forma natural.',
    features: ['Fórmula enzimática avanzada', 'Elimina olores persistentes', 'Base 100% natural', 'Acción profunda'],
    image: '🧴',
    badge: 'MÁS VENDIDO',
    inStock: true,
    rating: 5.0,
    reviews: 203
  },
  {
    id: 'clean-002',
    name: 'Limpiador Enzimático Premium',
    category: 'cleaners',
    price: 42.50,
    originalPrice: 52.90,
    description: 'Fórmula avanzada con enzimas que descomponen manchas orgánicas desde la raíz del tejido.',
    features: ['Elimina olores', 'Biodegradable', 'Acción profunda', 'Para todo tipo de telas'],
    image: '🧴',
    badge: 'OFERTA',
    inStock: true,
    rating: 4.7,
    reviews: 145
  },
  {
    id: 'clean-002',
    name: 'Shampoo para Alfombras Concentrado',
    category: 'cleaners',
    price: 38.75,
    description: 'Limpieza profunda para alfombras y tapetes. Fórmula concentrada de alto rendimiento.',
    features: ['Concentrado 1:10', 'Secado rápido', 'Sin residuos', 'Revive colores'],
    image: '✨',
    inStock: true,
    rating: 4.5,
    reviews: 134
  },
  {
    id: 'clean-003',
    name: 'Espuma Activa Multiuso',
    category: 'cleaners',
    price: 32.50,
    description: 'Espuma de acción rápida para manchas difíciles. Ideal para emergencias y limpieza localizada.',
    features: ['Acción en 30 seg', 'Sin residuos', 'Para todo tipo de manchas', 'Fácil de usar'],
    image: '🧽',
    badge: 'NUEVO',
    inStock: true,
    rating: 4.4,
    reviews: 78
  },
  {
    id: 'clean-004',
    name: 'Limpiador de Cuero Premium',
    category: 'cleaners',
    price: 56.90,
    description: 'Especializado para limpieza y cuidado de muebles de cuero genuino y sintético.',
    features: ['Nutre el cuero', 'Restaura flexibilidad', 'Protege contra grietas', 'Brillo natural'],
    image: '🎒',
    inStock: true,
    rating: 4.8,
    reviews: 92
  },
  {
    id: 'clean-005',
    name: 'Quitamanchas Experto',
    category: 'cleaners',
    price: 35.90,
    description: 'Potente quitamanchas para las manchas más difíciles: vino, café, grasa y más.',
    features: ['Manchas difíciles', 'Acción inmediata', 'No daña colores', 'Fórmula concentrada'],
    image: '🎯',
    inStock: true,
    rating: 4.6,
    reviews: 145
  },

  // Desodorantes
  {
    id: 'deod-001',
    name: 'Desodorante Natural Plus',
    category: 'deodorizers',
    price: 28.90,
    description: 'Neutralizador de olores con extractos naturales. Perfecto para el mantenimiento diario.',
    features: ['100% Natural', 'Fragancia duradera', 'Elimina bacterias', 'Sin químicos'],
    image: '🌿',
    inStock: true,
    rating: 4.5,
    reviews: 167
  },
  {
    id: 'deod-002',
    name: 'Eliminador de Olores de Mascotas',
    category: 'deodorizers',
    price: 34.50,
    description: 'Especializado en eliminar olores de orina, pelo y otros olores de mascotas.',
    features: ['Elimina olores de mascotas', 'Previene re-marcado', 'Seguro para animales', 'Larga duración'],
    image: '🐕',
    badge: 'ESPECIALIZADO',
    inStock: true,
    rating: 4.7,
    reviews: 198
  },
  {
    id: 'deod-003',
    name: 'Ambientador Antibacterial',
    category: 'deodorizers',
    price: 26.90,
    description: 'Desodoriza y elimina bacterias, ideal para hogares con niños pequeños.',
    features: ['Antibacterial', 'Fragancia suave', 'Seguro para niños', 'Efecto duradero'],
    image: '🏠',
    inStock: true,
    rating: 4.4,
    reviews: 112
  },

  // Kits Completos
  {
    id: 'kit-001',
    name: 'Kit Hogar Completo',
    category: 'kits',
    price: 199.90,
    originalPrice: 280.00,
    description: 'Todo lo necesario para el cuidado profesional de tus muebles en un solo kit.',
    features: ['Limpiador profesional', 'Protector premium', 'Desodorante', 'Kit de herramientas'],
    image: '📦',
    badge: 'NUEVO',
    inStock: true,
    rating: 5.0,
    reviews: 89
  },
  {
    id: 'kit-002',
    name: 'Kit Mantenimiento Hogar Completo',
    category: 'kits',
    price: 89.90,
    originalPrice: 119.90,
    description: 'Kit completo con protector, limpiador y desodorante. Todo lo necesario para el cuidado integral de tus muebles.',
    features: ['3 productos esenciales', 'Ahorro del 25%', 'Guía de uso incluida', 'Para toda la casa'],
    image: '📦',
    badge: 'KIT POPULAR',
    inStock: true,
    rating: 4.8,
    reviews: 234
  },
  {
    id: 'kit-002',
    name: 'Kit Profesional Premium',
    category: 'kits',
    price: 159.90,
    originalPrice: 210.00,
    description: 'Kit profesional con herramientas y productos de grado comercial para resultados excepcionales.',
    features: ['6 productos profesionales', 'Herramientas incluidas', 'Manual técnico', 'Resultados garantizados'],
    image: '🏆',
    badge: 'PROFESIONAL',
    inStock: true,
    rating: 4.9,
    reviews: 87
  },
  {
    id: 'kit-003',
    name: 'Kit Emergencia Manchas',
    category: 'kits',
    price: 45.90,
    description: 'Kit de emergencia para actuar rápidamente ante cualquier mancha accidental.',
    features: ['Acción inmediata', 'Portátil', 'Todo tipo de manchas', 'Fácil de usar'],
    image: '🚨',
    badge: 'EMERGENCIA',
    inStock: true,
    rating: 4.6,
    reviews: 156
  },

  // Herramientas
  {
    id: 'tool-001',
    name: 'Aspiradora de Mano Profesional',
    category: 'tools',
    price: 125.90,
    description: 'Aspiradora portátil de alta succión especial para limpieza de tapicería y muebles.',
    features: ['Alta succión', 'Batería recargable', 'Accesorios incluidos', 'Compacta y liviana'],
    image: '🔌',
    inStock: true,
    rating: 4.7,
    reviews: 145
  },
  {
    id: 'tool-002',
    name: 'Cepillos Especializados Set',
    category: 'tools',
    price: 23.90,
    description: 'Set de cepillos profesionales para diferentes tipos de tela y acabados.',
    features: ['4 cepillos diferentes', 'Cerdas especializadas', 'Mangos ergonómicos', 'Duraderos'],
    image: '🖌️',
    inStock: true,
    rating: 4.5,
    reviews: 89
  },
  {
    id: 'tool-003',
    name: 'Pulverizador Profesional',
    category: 'tools',
    price: 18.50,
    description: 'Pulverizador de calidad profesional con boquilla ajustable para aplicación precisa.',
    features: ['Boquilla ajustable', 'Resistente a químicos', 'Gatillo ergonómico', 'Capacidad 500ml'],
    image: '💧',
    inStock: true,
    rating: 4.3,
    reviews: 67
  },

  // Accesorios
  {
    id: 'acc-001',
    name: 'Paños de Microfibra Premium',
    category: 'accessories',
    price: 15.90,
    description: 'Set de paños de microfibra de alta calidad para limpieza sin rayar superficies.',
    features: ['Pack de 6 paños', 'Super absorbentes', 'No rayan', 'Lavables en máquina'],
    image: '🧽',
    inStock: true,
    rating: 4.6,
    reviews: 203
  },
  {
    id: 'acc-002',
    name: 'Guantes de Protección',
    category: 'accessories',
    price: 8.90,
    description: 'Guantes resistentes a químicos para protección durante la limpieza.',
    features: ['Resistentes a químicos', 'Talla única', 'Reutilizables', 'Antideslizantes'],
    image: '🧤',
    inStock: true,
    rating: 4.2,
    reviews: 134
  },
  {
    id: 'acc-003',
    name: 'Medidor de pH Digital',
    category: 'accessories',
    price: 35.90,
    description: 'Medidor digital para verificar el pH de las soluciones de limpieza.',
    features: ['Lectura digital', 'Alta precisión', 'Fácil calibración', 'Estuche incluido'],
    image: '📊',
    badge: 'PROFESIONAL',
    inStock: false,
    rating: 4.8,
    reviews: 45
  }
];

export const Products: React.FC<ProductsProps> = ({ className = '', onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [sortBy, setSortBy] = useState('popular');
  const [priceRange, setPriceRange] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 20;

  const filteredProducts = products.filter(product => {
    // Category filter
    if (selectedCategory !== 'all' && product.category !== selectedCategory) return false;
    
    // Search filter
    if (searchTerm && !product.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !product.description.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }
    
    return true;
  }).filter(product => {
    // Price filter
    if (priceRange === 'all') return true;
    if (priceRange === 'under30') return product.price < 30;
    if (priceRange === '30to50') return product.price >= 30 && product.price <= 50;
    if (priceRange === 'over50') return product.price > 50;
    return true;
  }).sort((a, b) => {
    if (sortBy === 'price-low') return a.price - b.price;
    if (sortBy === 'price-high') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    if (sortBy === 'newest') return b.id.localeCompare(a.id);
    return b.reviews - a.reviews; // popular
  });

  // Pagination logic
  const totalItems = filteredProducts.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const paginatedProducts = filteredProducts.slice(startIndex, endIndex);
  
  // Reset to page 1 when filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCategory, searchTerm, priceRange, sortBy]);

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`} className="star full">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  const addToCart = (product: Product) => {
    if (onAddToCart) {
      onAddToCart({
        id: product.id,
        type: 'product',
        name: product.name,
        price: product.originalPrice && product.originalPrice > product.price ? product.price : product.price,
        image: product.image
      });
    }
    alert(`${product.name} añadido al carrito!`);
  };

  return (
    <div className={`products ${className}`}>
      <div className="products__container">
        {/* Header */}
        <div className="products__header">
          <div className="products__title-section">
            <h1 className="products__title">Catálogo de Productos</h1>
            <p className="products__subtitle">
              Productos profesionales de limpieza para el cuidado integral de tus muebles y tapices
            </p>
          </div>
          
          <div className="products__stats">
            <div className="products__stat">
              <span className="products__stat-number">{products.length}</span>
              <span className="products__stat-label">Productos Disponibles</span>
            </div>
            <div className="products__stat">
              <span className="products__stat-number">{products.filter(p => p.onSale).length}</span>
              <span className="products__stat-label">En Oferta</span>
            </div>
            <div className="products__stat">
              <span className="products__stat-number">4.8</span>
              <span className="products__stat-label">Calificación Promedio</span>
            </div>
          </div>
        </div>

        {/* Main Layout: Sidebar + Content */}
        <div className="products__layout">
          {/* Sidebar with Filters */}
          <aside className="products__sidebar">
            <div className="products__sidebar-section">
              <h3 className="products__sidebar-title">Buscar</h3>
              <div className="products__search">
                <input
                  type="text"
                  placeholder="Buscar productos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="products__search-input"
                />
                <span className="products__search-icon">🔍</span>
              </div>
              {searchTerm && (
                <button
                  className="products__clear-search"
                  onClick={() => setSearchTerm('')}
                >
                  Limpiar búsqueda
                </button>
              )}
            </div>

            <div className="products__sidebar-section">
              <h3 className="products__sidebar-title">Categorías</h3>
              <div className="products__categories">
                {productCategories.map(category => (
                  <button
                    key={category.id}
                    className={`products__category ${selectedCategory === category.id ? 'active' : ''}`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="products__category-icon">{category.icon}</span>
                    <span className="products__category-name">{category.name}</span>
                    <span className="products__category-count">
                      ({selectedCategory === 'all' 
                        ? filteredProducts.filter(p => category.id === 'all' || p.category === category.id).length
                        : category.id === 'all' 
                          ? products.length 
                          : products.filter(p => p.category === category.id).length})
                    </span>
                  </button>
                ))}
              </div>
            </div>

            <div className="products__sidebar-section">
              <h3 className="products__sidebar-title">Filtros</h3>
              <div className="products__filter-group">
                <label className="products__filter-label">Rango de Precio</label>
                <select 
                  value={priceRange} 
                  onChange={(e) => setPriceRange(e.target.value)}
                  className="products__filter-select"
                >
                  <option value="all">Todos los precios</option>
                  <option value="under30">Menos de S/ 30</option>
                  <option value="30to50">S/ 30 - S/ 50</option>
                  <option value="over50">Más de S/ 50</option>
                </select>
              </div>

              <div className="products__filter-group">
                <label className="products__filter-label">Disponibilidad</label>
                <div className="products__checkbox-group">
                  <label className="products__checkbox">
                    <input type="checkbox" defaultChecked />
                    <span>En stock</span>
                  </label>
                  <label className="products__checkbox">
                    <input type="checkbox" />
                    <span>Próximamente</span>
                  </label>
                </div>
              </div>

              <div className="products__filter-group">
                <label className="products__filter-label">Ofertas</label>
                <div className="products__checkbox-group">
                  <label className="products__checkbox">
                    <input type="checkbox" />
                    <span>Solo ofertas</span>
                  </label>
                  <label className="products__checkbox">
                    <input type="checkbox" />
                    <span>Descuentos especiales</span>
                  </label>
                </div>
              </div>
            </div>
          </aside>

          {/* Main Content */}
          <main className="products__main">
            {/* Top Bar with Results and Sorting */}
            <div className="products__top-bar">
              <div className="products__results-info">
                <span className="products__results-count">
                  {totalPages > 1 
                    ? `Mostrando ${startIndex + 1} al ${Math.min(endIndex, totalItems)} de ${totalItems} producto${totalItems !== 1 ? 's' : ''}`
                    : `Mostrando ${totalItems} producto${totalItems !== 1 ? 's' : ''}`
                  }
                </span>
              </div>
              
              <div className="products__sort">
                <label className="products__sort-label">Ordenar por:</label>
                <select 
                  value={sortBy} 
                  onChange={(e) => setSortBy(e.target.value)}
                  className="products__sort-select"
                >
                  <option value="popular">Más Popular</option>
                  <option value="price-low">Precio: Menor a Mayor</option>
                  <option value="price-high">Precio: Mayor a Menor</option>
                  <option value="rating">Mejor Valorados</option>
                  <option value="newest">Más Nuevos</option>
                </select>
              </div>
            </div>

            {/* Products Grid */}
            <div className="products__grid">
          {paginatedProducts.map(product => (
            <div key={product.id} className="products__card">
              {product.badge && (
                <div className={`products__badge products__badge--${product.badge.toLowerCase()}`}>
                  {product.badge}
                </div>
              )}

              <div className="products__card-header">
                <div className="products__image">{product.image}</div>
                <div className="products__card-info">
                  <h3 className="products__name">{product.name}</h3>
                  <div className="products__category-badge">
                    {productCategories.find(c => c.id === product.category)?.name || 'Producto'}
                  </div>
                </div>
              </div>

              <div className="products__pricing">
                <div className="products__price-section">
                  <div className="products__price-main">
                    {product.originalPrice && (
                      <span className="products__price-original">
                        S/ {product.originalPrice.toFixed(2)}
                      </span>
                    )}
                    <span className="products__price-current">
                      S/ {product.price.toFixed(2)}
                    </span>
                  </div>
                  <div className="products__stock">
                    <span className="products__stock-icon">📦</span>
                    <span className="products__stock-text">{product.inStock ? 'En stock' : 'Agotado'}</span>
                  </div>
                </div>

                {product.originalPrice && product.originalPrice > product.price && (
                  <div className="products__savings">
                    Ahorras S/ {(product.originalPrice - product.price).toFixed(2)}
                  </div>
                )}
              </div>

              <div className="products__description">
                <p>{product.description}</p>
              </div>

              <div className="products__features">
                <ul className="products__features-list">
                  {product.features.slice(0, 3).map((feature, index) => (
                    <li key={index} className="products__feature">
                      <span className="products__feature-icon">✓</span>
                      {feature}
                    </li>
                  ))}
                  {product.features.length > 3 && (
                    <li className="products__feature products__feature--more">
                      +{product.features.length - 3} más
                    </li>
                  )}
                </ul>
              </div>

              <div className="products__rating">
                <div className="products__stars">
                  {renderStars(product.rating)}
                </div>
                <span className="products__rating-text">
                  {product.rating} ({product.reviews} reseñas)
                </span>
              </div>

              <div className="products__actions">
                <Button 
                  variant="primary" 
                  className="products__add-btn"
                  onClick={() => addToCart(product)}
                  disabled={!product.inStock}
                >
                  {product.inStock ? 'Añadir al Carrito' : 'Agotado'}
                </Button>
                <Button variant="outline" size="small" className="products__info-btn">
                  Más Info
                </Button>
              </div>

              {!product.inStock && (
                <div className="products__unavailable">
                  <span>Temporalmente agotado</span>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="products__pagination">
            <button 
              className="products__page-btn"
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
            >
              ← Anterior
            </button>
            
            <div className="products__page-info">
              <span>Página {currentPage} de {totalPages}</span>
            </div>
            
            <div className="products__page-numbers">
              {Array.from({ length: totalPages }, (_, i) => i + 1)
                .filter(page => {
                  // Show first page, last page, current page, and pages around current
                  return page === 1 || 
                         page === totalPages || 
                         (page >= currentPage - 1 && page <= currentPage + 1);
                })
                .map((page, index, array) => (
                  <React.Fragment key={page}>
                    {index > 0 && array[index - 1] < page - 1 && <span className="products__page-dots">...</span>}
                    <button
                      className={`products__page-number ${currentPage === page ? 'active' : ''}`}
                      onClick={() => setCurrentPage(page)}
                    >
                      {page}
                    </button>
                  </React.Fragment>
                ))
              }
            </div>
            
            <button 
              className="products__page-btn"
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
            >
              Siguiente →
            </button>
          </div>
        )}

        {totalItems === 0 && (
          <div className="products__empty-state">
            <div className="products__empty-icon">🔍</div>
            <h3 className="products__empty-title">No se encontraron productos</h3>
            <p className="products__empty-text">
              {searchTerm 
                ? `No hay productos que coincidan con "${searchTerm}"`
                : 'No hay productos en esta categoría'
              }
            </p>
            <Button 
              variant="outline" 
              onClick={() => {
                setSearchTerm('');
                setSelectedCategory('all');
              }}
            >
              Ver todos los productos
            </Button>
          </div>
        )}
          </main>
        </div>
      </div>
    </div>
  );
};

export default Products;