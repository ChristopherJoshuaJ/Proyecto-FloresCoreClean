import React, { useState, useEffect, useRef } from 'react';
import Button from '../Button';
import './Header.less';

export interface HeaderProps {
  siteName?: string;
  className?: string;
  onQuoteRequest?: () => void;
  phoneNumber?: string;
  onNavigation?: (page: string, tab?: string) => void;
  currentPage?: string;
  isLoggedIn?: boolean;
  user?: { name: string; email: string; role?: string } | null;
  onLogout?: () => void;
  cartItemCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  siteName = 'FloresCore',
  className = '',
  onQuoteRequest,
  phoneNumber = '+51 999 888 777',
  onNavigation,
  currentPage = 'home',
  isLoggedIn = false,
  user = null,
  onLogout,
  cartItemCount = 0,
}) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showUserDropdown, setShowUserDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowUserDropdown(false);
      }
    };

    if (showUserDropdown) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [showUserDropdown]);

  const handleNavigation = (page: string) => {
    if (onNavigation) {
      onNavigation(page);
    }
    setIsMobileMenuOpen(false);
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className={`header ${className}`}>
      {/* Simple navigation bar like the old design */}
      <nav className="nav">
        <ul className={isMobileMenuOpen ? 'open' : ''}>
          <li>
            <button 
              className={`btn ${currentPage === 'home' ? 'active' : ''}`} 
              onClick={() => handleNavigation('home')}
            >
              Inicio
            </button>
          </li>
          <li>
            <button 
              className={`btn ${currentPage === 'products' ? 'active' : ''}`} 
              onClick={() => handleNavigation('products')}
            >
              Productos
            </button>
          </li>
          <li>
            <button 
              className={`btn ${currentPage === 'services' ? 'active' : ''}`} 
              onClick={() => handleNavigation('services')}
            >
              Servicios
            </button>
          </li>
          <li>
            <button 
              className={`btn ${currentPage === 'about' ? 'active' : ''}`} 
              onClick={() => handleNavigation('about')}
            >
              Nosotros
            </button>
          </li>
          <li>
            <button 
              className={`btn ${currentPage === 'contact' ? 'active' : ''}`} 
              onClick={() => handleNavigation('contact')}
            >
              Contacto
            </button>
          </li>
        </ul>
        <button 
          className={`burger ${isMobileMenuOpen ? 'open' : ''}`}
          onClick={toggleMobileMenu}
          aria-label="Abrir menú"
          aria-expanded={isMobileMenuOpen}
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
      </nav>
      
      <div className="header-actions">
        {isLoggedIn && (
          <button 
            className={`btn cart-btn ${currentPage === 'dashboard' ? 'active' : ''}`} 
            onClick={() => onNavigation?.('dashboard', 'cart')}
            title="Ver carrito de compras"
          >
            🛒
            {cartItemCount > 0 && (
              <span className="cart-badge">{cartItemCount}</span>
            )}
          </button>
        )}
        
        {isLoggedIn && user ? (
          <div className="header-user">
            <div className="header-user-dropdown" ref={dropdownRef}>
              <button 
                className="header-user-dropdown__trigger"
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                title="Menú de usuario"
              >
                <span className="header-user-dropdown__avatar">👤</span>
                <span className="header-user-dropdown__name">{user.name.split(' ')[0]}</span>
                <span className="header-user-dropdown__chevron">⌄</span>
              </button>
              
              {showUserDropdown && (
                <div className="header-user-dropdown__menu">
                  <div className="header-user-dropdown__header">
                    <div className="header-user-dropdown__avatar-large">👤</div>
                    <div className="header-user-dropdown__info">
                      <div className="header-user-dropdown__full-name">{user.name}</div>
                      <div className="header-user-dropdown__email">{user.email}</div>
                    </div>
                  </div>
                  
                  <div className="header-user-dropdown__divider"></div>
                  
                  {user?.role === 'admin' && (
                    <button 
                      className="header-user-dropdown__item"
                      onClick={() => {
                        handleNavigation('admin-dashboard');
                        setShowUserDropdown(false);
                      }}
                    >
                      <span className="header-user-dropdown__item-icon">⚙️</span>
                      Panel Admin
                    </button>
                  )}
                  
                  <button 
                    className="header-user-dropdown__item"
                    onClick={() => {
                      handleNavigation('dashboard');
                      setShowUserDropdown(false);
                    }}
                  >
                    <span className="header-user-dropdown__item-icon">📊</span>
                    {user?.role === 'admin' ? 'Panel Usuario' : 'Mi Panel'}
                  </button>
                  
                  <button 
                    className="header-user-dropdown__item"
                    onClick={() => {
                      if (onNavigation) {
                        onNavigation('dashboard', 'cart');
                      }
                      setShowUserDropdown(false);
                    }}
                  >
                    <span className="header-user-dropdown__item-icon">🛒</span>
                    Mi Carrito
                    {cartItemCount > 0 && (
                      <span className="header-user-dropdown__badge">{cartItemCount}</span>
                    )}
                  </button>
                  
                  <button 
                    className="header-user-dropdown__item"
                    onClick={() => {
                      if (onNavigation) {
                        onNavigation('dashboard', 'profile');
                      }
                      setShowUserDropdown(false);
                    }}
                  >
                    <span className="header-user-dropdown__item-icon">👤</span>
                    Mi Perfil
                  </button>
                  
                  <div className="header-user-dropdown__divider"></div>
                  
                  <button 
                    className="header-user-dropdown__item header-user-dropdown__item--logout"
                    onClick={() => {
                      onLogout?.();
                      setShowUserDropdown(false);
                    }}
                  >
                    <span className="header-user-dropdown__item-icon">🚪</span>
                    Cerrar Sesión
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <button className="btn" onClick={() => handleNavigation('login')}>
            Iniciar sesión
          </button>
        )}
      </div>

      {/* Hidden complex structure */}
      <div style={{ display: 'none' }}>
        {/* Top Bar with Contact Info */}
        <div className="header__top-bar">
          <div className="header__container">
            <div className="header__contact-info">
              <span className="header__phone">📞 {phoneNumber}</span>
              <span className="header__location">📍 Lima, Perú - Servicio a domicilio</span>
            </div>
            <div className="header__top-right">
            </div>
          </div>
        </div>

        {/* Main Header */}
        <div className="header__main">
          <div className="header__container">
            {/* Logo */}
            <div className="header__logo">
              <h1 className="header__site-name">{siteName}</h1>
              <span className="header__tagline">Limpieza que Transforma tu Espacio</span>
            </div>

            {/* Navigation */}
            <nav className="header__nav">
              <ul className="header__nav-list">
                <li className="header__nav-item">
                  <a href="#inicio" className="header__nav-link">Inicio</a>
                </li>
                <li className="header__nav-item">
                  <a href="#servicios" className="header__nav-link">Servicios</a>
                </li>
                <li className="header__nav-item">
                  <a href="#productos" className="header__nav-link">Productos</a>
                </li>
                <li className="header__nav-item">
                  <a href="#nosotros" className="header__nav-link">Nosotros</a>
                </li>
                <li className="header__nav-item">
                  <a href="#contacto" className="header__nav-link">Contacto</a>
                </li>
              </ul>
            </nav>

            {/* CTA Button */}
            <div className="header__cta">
              <Button variant="primary" onClick={onQuoteRequest}>
                Solicitar Cotización
              </Button>
            </div>

            {/* Mobile Menu Toggle */}
            <Button
              variant="outline"
              size="small"
              className="header__mobile-toggle"
              onClick={toggleMobileMenu}
              aria-label="Toggle mobile menu"
              aria-expanded={isMobileMenuOpen}
            >
              ☰
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div className={`header__mobile-menu ${isMobileMenuOpen ? 'header__mobile-menu--open' : ''}`}>
          <nav className="header__mobile-nav">
            <ul className="header__mobile-nav-list">
              <li className="header__mobile-nav-item">
                <a href="#inicio" className="header__mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>
                  Inicio
                </a>
              </li>
              <li className="header__mobile-nav-item">
                <a href="#servicios" className="header__mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>
                  Servicios
                </a>
              </li>
              <li className="header__mobile-nav-item">
                <a href="#productos" className="header__mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>
                  Productos
                </a>
              </li>
              <li className="header__mobile-nav-item">
                <a href="#nosotros" className="header__mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>
                  Nosotros
                </a>
              </li>
              <li className="header__mobile-nav-item">
                <a href="#contacto" className="header__mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>
                  Contacto
                </a>
              </li>
              <li className="header__mobile-nav-item">
                <Button variant="primary" onClick={onQuoteRequest} className="header__mobile-cta">
                  Solicitar Cotización
                </Button>
              </li>
            </ul>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;