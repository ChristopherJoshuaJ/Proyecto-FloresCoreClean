import { useState, useEffect } from 'react'
import Header from './components/Header'
import Button from './components/Button'
import Products from './components/Products'
import Services from './components/Services/Services'
import Login from './components/Login'
import UserDashboard from './components/UserDashboard'
import AdminDashboard from './components/AdminDashboard'
import { authenticateUser } from './utils/mockData'
import type { User, CartItem } from './utils/mockData'
import './styles/App.less'

// Featured products for home page
const featuredProducts = [
  {
    id: 'prot-001',
    name: 'ScotchGard Pro Shield',
    category: 'PROTECTORES',
    price: 89.90,
    originalPrice: 120.00,
    description: 'Protector antimanchas profesional de última generación. Ideal para muebles de tela y cuero.',
    image: '🛡️',
    badge: '¡OFERTA!',
    rating: 5.0,
    reviews: 127,
    inStock: true,
    features: ['Protección antimanchas', 'Fórmula profesional', 'Para tela y cuero', 'Larga duración']
  },
  {
    id: 'clean-001',
    name: 'UltraClean Enzyme',
    category: 'LIMPIADORES',
    price: 75.00,
    description: 'Limpiador enzimático que elimina manchas difíciles y olores persistentes de forma natural.',
    image: '🧴',
    badge: 'MÁS VENDIDO',
    rating: 5.0,
    reviews: 203,
    inStock: true,
    features: ['Fórmula enzimática avanzada', 'Elimina olores persistentes', 'Base 100% natural', 'Acción profunda']
  },
  {
    id: 'kit-001',
    name: 'Kit Hogar Completo',
    category: 'KITS',
    price: 199.90,
    originalPrice: 280.00,
    description: 'Todo lo necesario para el cuidado profesional de tus muebles en un solo kit.',
    image: '📦',
    badge: 'NUEVO',
    rating: 5.0,
    reviews: 89,
    inStock: true,
    features: ['3 productos esenciales', 'Ahorro del 25%', 'Guía de uso incluida', 'Kit completo']
  }
];

// Featured services for home page
const featuredServices = [
  {
    id: 'serv-001',
    name: 'Limpieza de Sofás',
    category: 'MUEBLES',
    startingPrice: 120,
    estimatedDuration: '2-3 horas',
    description: 'Lavado profundo de sofás, sillas y muebles tapizados con productos especializados.',
    image: '🧽',
    rating: 4.9,
    reviews: 234,
    features: ['Servicio integral', 'Múltiples superficies', 'Descuento por paquete', 'Garantía incluida']
  },
  {
    id: 'serv-002',
    name: 'Lavado de Alfombras',
    category: 'ALFOMBRAS',
    startingPrice: 80,
    estimatedDuration: '1-2 horas',
    description: 'Limpieza profunda con eliminación de manchas, ácaros y olores desagradables.',
    image: '🏠',
    rating: 4.8,
    reviews: 189,
    features: ['Eliminación de ácaros', 'Tratamiento de manchas', 'Secado rápido', 'Productos ecológicos']
  },
  {
    id: 'serv-003',
    name: 'Tratamiento de Cuero',
    category: 'CUERO',
    startingPrice: 150,
    estimatedDuration: '2-4 horas',
    description: 'Cuidado especializado para muebles de cuero con nutrición y protección.',
    image: '🪑',
    rating: 4.9,
    reviews: 156,
    features: ['Nutrición especializada', 'Protección UV', 'Restauración de color', 'Acabado profesional']
  }
];

function App() {
  const [currentTheme, setCurrentTheme] = useState('green')
  const [currentPage, setCurrentPage] = useState('home') // 'home', 'products', 'services', 'about', 'contact', 'login', 'dashboard', 'admin-dashboard'
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [user, setUser] = useState<User | null>(null)
  const [cartItems, setCartItems] = useState<CartItem[]>([])
  const [dashboardTab, setDashboardTab] = useState<'overview' | 'orders' | 'cart' | 'profile' | 'settings'>('overview')

  const renderStars = (rating: number) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const stars = [];

    for (let i = 0; i < fullStars; i++) {
      stars.push(<span key={`full-${i}`} className="star full">★</span>);
    }

    if (hasHalfStar) {
      stars.push(<span key="half" className="star half">★</span>);
    }

    const emptyStars = 5 - Math.ceil(rating);
    for (let i = 0; i < emptyStars; i++) {
      stars.push(<span key={`empty-${i}`} className="star empty">☆</span>);
    }

    return stars;
  };

  // Apply theme to document body
  useEffect(() => {
    // Remove all theme classes
    document.body.className = document.body.className.replace(/theme-\w+/g, '').trim()
    // Add new theme class
    document.body.classList.add(`theme-${currentTheme}`)
    
    return () => {
      // Cleanup on unmount
      document.body.className = document.body.className.replace(/theme-\w+/g, '').trim()
    }
  }, [currentTheme])

  const handleThemeChange = (theme: string) => {
    setCurrentTheme(theme)
  }

  const handleQuoteRequest = () => {
    alert('¡Solicitud de cotización enviada! Nos contactaremos contigo pronto.')
  }

  const handleNavigation = (page: string, tab?: string) => {
    setCurrentPage(page)
    if (page === 'dashboard' && tab) {
      setDashboardTab(tab as 'overview' | 'orders' | 'cart' | 'profile' | 'settings')
    }
  }

  const handleLogin = (credentials: { email: string; password: string }) => {
    const authenticatedUser = authenticateUser(credentials.email, credentials.password)
    
    if (authenticatedUser) {
      setUser(authenticatedUser)
      setIsLoggedIn(true)
      // Redirect admin users to admin dashboard, regular users to user dashboard
      setCurrentPage(authenticatedUser.role === 'admin' ? 'admin-dashboard' : 'dashboard')
      alert(`¡Bienvenido ${authenticatedUser.firstName}! ${authenticatedUser.role === 'admin' ? '(Administrador)' : ''}`)
    } else {
      alert('Credenciales incorrectas. Prueba:\n\nUsuario: usuario@test.com / 123456\nAdmin: admin@florescore.com / admin123\nCliente: cliente@email.com / cliente123')
    }
  }

  const handleLogout = () => {
    setUser(null)
    setIsLoggedIn(false)
    setCurrentPage('home')
    setCartItems([]) // Clear cart on logout
    alert('Has cerrado sesión correctamente')
  }

  // Shopping Cart Functions
  const addToCart = (item: { id: string; type: 'product' | 'service'; name: string; price: number; image: string; selectedVariant?: string }) => {
    const existingItem = cartItems.find(cartItem => 
      cartItem.id === item.id && cartItem.type === item.type && cartItem.selectedVariant === item.selectedVariant
    );

    if (existingItem) {
      setCartItems(prev => prev.map(cartItem => 
        cartItem === existingItem 
          ? { ...cartItem, quantity: cartItem.quantity + 1 }
          : cartItem
      ));
    } else {
      const newCartItem: CartItem = {
        ...item,
        quantity: 1,
        addedAt: new Date().toISOString()
      };
      setCartItems(prev => [...prev, newCartItem]);
    }
  };

  const removeFromCart = (itemId: string, type: 'product' | 'service', selectedVariant?: string) => {
    setCartItems(prev => prev.filter(item => 
      !(item.id === itemId && item.type === type && item.selectedVariant === selectedVariant)
    ));
  };

  const updateCartQuantity = (itemId: string, type: 'product' | 'service', quantity: number, selectedVariant?: string) => {
    if (quantity <= 0) {
      removeFromCart(itemId, type, selectedVariant);
      return;
    }

    setCartItems(prev => prev.map(item => 
      item.id === itemId && item.type === type && item.selectedVariant === selectedVariant
        ? { ...item, quantity }
        : item
    ));
  };

  const clearCart = () => {
    setCartItems([]);
  };

  const getCartTotal = () => {
    return cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  };

  const getCartItemCount = () => {
    return cartItems.reduce((count, item) => count + item.quantity, 0);
  };

  const renderPage = () => {
    switch (currentPage) {
      case 'products':
        return <Products onAddToCart={addToCart} />
      case 'login':
        return <Login onLogin={handleLogin} />
      case 'dashboard':
        return user ? (
          <UserDashboard 
            user={user} 
            onLogout={handleLogout}
            onNavigation={handleNavigation}
            currentTheme={currentTheme}
            onThemeChange={handleThemeChange}
            cartItems={cartItems}
            onRemoveFromCart={removeFromCart}
            onUpdateCartQuantity={updateCartQuantity}
            onClearCart={clearCart}
            cartTotal={getCartTotal()}
            cartItemCount={getCartItemCount()}
            initialTab={dashboardTab}
          />
        ) : null
      case 'admin-dashboard':
        return user && user.role === 'admin' ? (
          <AdminDashboard 
            user={user} 
            onLogout={handleLogout}
            onNavigation={handleNavigation}
            currentTheme={currentTheme}
            onThemeChange={handleThemeChange}
          />
        ) : null
      case 'services':
        return <Services onAddToCart={addToCart} />
      case 'about':
        return (
          <div className="app__about">
            {/* Hero Section */}
            <section className="app__about-hero">
              <div className="container">
                <div className="app__about-hero-content">
                  <h1 className="app__about-title">Sobre Nosotros</h1>
                  <p className="app__about-subtitle">
                    Más de 10 años transformando hogares y oficinas con servicios de limpieza profesional
                  </p>
                </div>
              </div>
            </section>

            {/* Company Story */}
            <section className="app__about-story">
              <div className="container">
                <div className="app__about-grid">
                  <div className="app__about-text">
                    <h2>Nuestra Historia</h2>
                    <p>
                      Flores Core Clean nació en 2013 con la visión de revolucionar los servicios de limpieza 
                      en el mercado peruano. Lo que comenzó como una pequeña empresa familiar se ha convertido 
                      en la referencia en limpieza profesional para hogares y oficinas.
                    </p>
                    <p>
                      Nos especializamos en servicios de limpieza profunda, mantenimiento de muebles, tratamiento 
                      de alfombras y tapicería, utilizando productos ecológicos y técnicas avanzadas que garantizan 
                      resultados excepcionales sin comprometer la salud de nuestros clientes.
                    </p>
                  </div>
                  <div className="app__about-image">
                    <div className="app__about-placeholder">
                      🏢 Nuestra Empresa
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* Mission & Vision */}
            <section className="app__about-mission">
              <div className="container">
                <div className="app__mission-vision-grid">
                  <div className="app__mission-card">
                    <div className="app__mission-icon">🎯</div>
                    <h3>Nuestra Misión</h3>
                    <p>
                      Proporcionar servicios de limpieza de excelencia que superen las expectativas de nuestros 
                      clientes, utilizando productos ecológicos y técnicas innovadoras para crear espacios más 
                      saludables y confortables.
                    </p>
                  </div>
                  <div className="app__vision-card">
                    <div className="app__vision-icon">🌟</div>
                    <h3>Nuestra Visión</h3>
                    <p>
                      Ser la empresa líder en servicios de limpieza profesional en Perú, reconocida por nuestra 
                      calidad, confiabilidad y compromiso con el medio ambiente y la satisfacción del cliente.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Values */}
            <section className="app__about-values">
              <div className="container">
                <h2 className="app__values-title">Nuestros Valores</h2>
                <div className="app__values-grid">
                  <div className="app__value-item">
                    <div className="app__value-icon">✨</div>
                    <h4>Excelencia</h4>
                    <p>Nos comprometemos a entregar resultados excepcionales en cada servicio</p>
                  </div>
                  <div className="app__value-item">
                    <div className="app__value-icon">🤝</div>
                    <h4>Confianza</h4>
                    <p>Construimos relaciones duraderas basadas en la honestidad y transparencia</p>
                  </div>
                  <div className="app__value-item">
                    <div className="app__value-icon">🌱</div>
                    <h4>Sostenibilidad</h4>
                    <p>Utilizamos productos ecológicos que cuidan el medio ambiente</p>
                  </div>
                  <div className="app__value-item">
                    <div className="app__value-icon">⚡</div>
                    <h4>Innovación</h4>
                    <p>Incorporamos las últimas tecnologías y métodos de limpieza</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Team */}
            <section className="app__about-team">
              <div className="container">
                <h2 className="app__team-title">Nuestro Equipo</h2>
                <p className="app__team-subtitle">
                  Profesionales altamente capacitados y comprometidos con la excelencia
                </p>
                <div className="app__team-grid">
                  <div className="app__team-member">
                    <div className="app__member-photo">👨‍💼</div>
                    <h4>Carlos Flores</h4>
                    <p className="app__member-role">CEO & Fundador</p>
                    <p className="app__member-description">
                      Más de 15 años de experiencia en el sector de servicios de limpieza
                    </p>
                  </div>
                  <div className="app__team-member">
                    <div className="app__member-photo">👩‍💼</div>
                    <h4>María González</h4>
                    <p className="app__member-role">Directora de Operaciones</p>
                    <p className="app__member-description">
                      Especialista en gestión de calidad y procesos operativos
                    </p>
                  </div>
                  <div className="app__team-member">
                    <div className="app__member-photo">👨‍🔬</div>
                    <h4>Luis Mendoza</h4>
                    <p className="app__member-role">Jefe Técnico</p>
                    <p className="app__member-description">
                      Experto en productos de limpieza y técnicas especializadas
                    </p>
                  </div>
                  <div className="app__team-member">
                    <div className="app__member-photo">👩‍💻</div>
                    <h4>Ana Vargas</h4>
                    <p className="app__member-role">Atención al Cliente</p>
                    <p className="app__member-description">
                      Dedicada a brindar la mejor experiencia a nuestros clientes
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Stats */}
            <section className="app__about-stats">
              <div className="container">
                <h2 className="app__stats-title">Números que nos Respaldan</h2>
                <div className="app__stats-grid">
                  <div className="app__stat-item">
                    <div className="app__stat-number">10+</div>
                    <div className="app__stat-label">Años de Experiencia</div>
                  </div>
                  <div className="app__stat-item">
                    <div className="app__stat-number">5000+</div>
                    <div className="app__stat-label">Clientes Satisfechos</div>
                  </div>
                  <div className="app__stat-item">
                    <div className="app__stat-number">15000+</div>
                    <div className="app__stat-label">Servicios Realizados</div>
                  </div>
                  <div className="app__stat-item">
                    <div className="app__stat-number">98%</div>
                    <div className="app__stat-label">Satisfacción del Cliente</div>
                  </div>
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="app__about-cta">
              <div className="container">
                <div className="app__cta-content">
                  <h2>¿Listo para Transformar tu Espacio?</h2>
                  <p>
                    Únete a miles de clientes satisfechos que confían en Flores Core Clean 
                    para mantener sus espacios impecables
                  </p>
                  <div className="app__cta-buttons">
                    <Button 
                      variant="primary" 
                      size="large"
                      onClick={() => handleNavigation('contact')}
                    >
                      Contáctanos
                    </Button>
                    <Button 
                      variant="outline" 
                      size="large"
                      onClick={() => handleNavigation('services')}
                    >
                      Ver Servicios
                    </Button>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )
      case 'contact':
        return (
          <div className="app__contact">
            {/* Hero Section */}
            <section className="app__contact-hero">
              <div className="container">
                <div className="app__contact-hero-content">
                  <h1 className="app__contact-title">Contáctanos</h1>
                  <p className="app__contact-subtitle">
                    Estamos aquí para ayudarte. Obtén tu cotización gratuita hoy mismo
                  </p>
                </div>
              </div>
            </section>

            {/* Main Content */}
            <section className="app__contact-main">
              <div className="container">
                <div className="app__contact-grid">
                  
                  {/* Contact Form */}
                  <div className="app__contact-form-section">
                    <h2>Solicita tu Cotización</h2>
                    <p className="app__form-description">
                      Completa el formulario y nos pondremos en contacto contigo en menos de 24 horas
                    </p>
                    
                    <form className="app__contact-form" onSubmit={(e) => {
                      e.preventDefault();
                      const formData = new FormData(e.target as HTMLFormElement);
                      const data = Object.fromEntries(formData);
                      console.log('Formulario enviado:', data);
                      alert('¡Mensaje enviado! Nos contactaremos contigo pronto.');
                      (e.target as HTMLFormElement).reset();
                    }}>
                      <div className="app__form-row">
                        <div className="app__form-group">
                          <label htmlFor="firstName">Nombre *</label>
                          <input 
                            type="text" 
                            id="firstName" 
                            name="firstName" 
                            required 
                            placeholder="Tu nombre"
                          />
                        </div>
                        <div className="app__form-group">
                          <label htmlFor="lastName">Apellido *</label>
                          <input 
                            type="text" 
                            id="lastName" 
                            name="lastName" 
                            required 
                            placeholder="Tu apellido"
                          />
                        </div>
                      </div>

                      <div className="app__form-row">
                        <div className="app__form-group">
                          <label htmlFor="email">Email *</label>
                          <input 
                            type="email" 
                            id="email" 
                            name="email" 
                            required 
                            placeholder="tu@email.com"
                          />
                        </div>
                        <div className="app__form-group">
                          <label htmlFor="phone">Teléfono *</label>
                          <input 
                            type="tel" 
                            id="phone" 
                            name="phone" 
                            required 
                            placeholder="+51 999 999 999"
                          />
                        </div>
                      </div>

                      <div className="app__form-group">
                        <label htmlFor="service">Tipo de Servicio *</label>
                        <select id="service" name="service" required>
                          <option value="">Selecciona un servicio</option>
                          <option value="limpieza-sofas">Limpieza de Sofás</option>
                          <option value="lavado-alfombras">Lavado de Alfombras</option>
                          <option value="tratamiento-cuero">Tratamiento de Cuero</option>
                          <option value="limpieza-tapiceria">Limpieza de Tapicería</option>
                          <option value="mantenimiento-oficina">Mantenimiento de Oficina</option>
                          <option value="limpieza-hogar">Limpieza de Hogar</option>
                          <option value="otro">Otro</option>
                        </select>
                      </div>

                      <div className="app__form-group">
                        <label htmlFor="address">Dirección</label>
                        <input 
                          type="text" 
                          id="address" 
                          name="address" 
                          placeholder="Dirección donde se realizará el servicio"
                        />
                      </div>

                      <div className="app__form-group">
                        <label htmlFor="message">Mensaje *</label>
                        <textarea 
                          id="message" 
                          name="message" 
                          rows={5} 
                          required
                          placeholder="Cuéntanos más detalles sobre el servicio que necesitas..."
                        ></textarea>
                      </div>

                      <div className="app__form-group">
                        <label className="app__checkbox-label">
                          <input type="checkbox" name="newsletter" />
                          <span className="app__checkbox-text">
                            Quiero recibir ofertas especiales y noticias por email
                          </span>
                        </label>
                      </div>

                      <Button type="submit" variant="primary" size="large" className="app__submit-btn">
                        Enviar Solicitud
                      </Button>
                    </form>
                  </div>

                  {/* Contact Information */}
                  <div className="app__contact-info-section">
                    <div className="app__contact-info">
                      <h3>Información de Contacto</h3>
                      
                      <div className="app__contact-item">
                        <div className="app__contact-icon">📍</div>
                        <div className="app__contact-details">
                          <h4>Dirección</h4>
                          <p>Av. Javier Prado Este 4200<br/>San Borja, Lima 15037</p>
                        </div>
                      </div>

                      <div className="app__contact-item">
                        <div className="app__contact-icon">📞</div>
                        <div className="app__contact-details">
                          <h4>Teléfono</h4>
                          <p>+51 1 234-5678<br/>+51 999 888 777</p>
                        </div>
                      </div>

                      <div className="app__contact-item">
                        <div className="app__contact-icon">✉️</div>
                        <div className="app__contact-details">
                          <h4>Email</h4>
                          <p>info@florescoreclean.com<br/>ventas@florescoreclean.com</p>
                        </div>
                      </div>

                      <div className="app__contact-item">
                        <div className="app__contact-icon">🕐</div>
                        <div className="app__contact-details">
                          <h4>Horarios de Atención</h4>
                          <p>Lunes a Viernes: 8:00 AM - 6:00 PM<br/>Sábados: 9:00 AM - 2:00 PM</p>
                        </div>
                      </div>
                    </div>

                    {/* Quick Contact Options */}
                    <div className="app__quick-contact">
                      <h3>Contacto Rápido</h3>
                      <div className="app__quick-buttons">
                        <a href="https://wa.me/51999888777" className="app__whatsapp-btn" target="_blank" rel="noopener noreferrer">
                          <span className="app__btn-icon">📱</span>
                          WhatsApp
                        </a>
                        <a href="tel:+5112345678" className="app__call-btn">
                          <span className="app__btn-icon">📞</span>
                          Llamar Ahora
                        </a>
                        <a href="mailto:info@florescoreclean.com" className="app__email-btn">
                          <span className="app__btn-icon">✉️</span>
                          Enviar Email
                        </a>
                      </div>
                    </div>

                    {/* Service Areas */}
                    <div className="app__service-areas">
                      <h3>Zonas de Servicio</h3>
                      <div className="app__areas-grid">
                        <div className="app__area-item">San Borja</div>
                        <div className="app__area-item">Miraflores</div>
                        <div className="app__area-item">San Isidro</div>
                        <div className="app__area-item">Surco</div>
                        <div className="app__area-item">La Molina</div>
                        <div className="app__area-item">Barranco</div>
                        <div className="app__area-item">Chorrillos</div>
                        <div className="app__area-item">Jesús María</div>
                      </div>
                      <p className="app__areas-note">
                        ¿No ves tu zona? <strong>Contáctanos</strong>, también atendemos otras áreas de Lima
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </section>

            {/* FAQ Section */}
            <section className="app__contact-faq">
              <div className="container">
                <h2 className="app__faq-title">Preguntas Frecuentes</h2>
                <div className="app__faq-grid">
                  <div className="app__faq-item">
                    <h4>¿Cuánto tiempo toma el servicio?</h4>
                    <p>Depende del tipo de servicio. La limpieza de sofás toma 2-3 horas, mientras que el lavado de alfombras puede tomar 1-2 horas.</p>
                  </div>
                  <div className="app__faq-item">
                    <h4>¿Los productos son seguros?</h4>
                    <p>Sí, utilizamos productos ecológicos y seguros para mascotas y niños. Todos nuestros productos están certificados.</p>
                  </div>
                  <div className="app__faq-item">
                    <h4>¿Ofrecen garantía?</h4>
                    <p>Ofrecemos garantía de satisfacción del 100%. Si no estás conforme, regresamos sin costo adicional.</p>
                  </div>
                  <div className="app__faq-item">
                    <h4>¿Atienden los fines de semana?</h4>
                    <p>Atendemos sábados hasta las 2:00 PM. Para servicios urgentes los domingos, consulta disponibilidad.</p>
                  </div>
                </div>
              </div>
            </section>

            {/* CTA Section */}
            <section className="app__contact-cta">
              <div className="container">
                <div className="app__cta-content">
                  <h2>¿Necesitas Ayuda Inmediata?</h2>
                  <p>Nuestro equipo está listo para atenderte. Llámanos ahora para servicios urgentes</p>
                  <div className="app__emergency-contact">
                    <a href="tel:+51999888777" className="app__emergency-btn">
                      🚨 Línea de Emergencia: +51 999 888 777
                    </a>
                  </div>
                </div>
              </div>
            </section>
          </div>
        )
      default:
        return renderHomePage()
    }
  }

  const renderHomePage = () => (
    <>
      {/* Hero Section */}
      <section className="app__hero">
        <div className="app__hero-content">
          <h1 className="app__hero-title">
            LIMPIEZA QUE <span className="app__hero-highlight">TRANSFORMA</span> TU ESPACIO
          </h1>
          <p className="app__hero-subtitle">
            Lavado, desmanchado y desinfectado de muebles y tapices
          </p>
          <p className="app__hero-location">
            Visita a domicilio GRATIS en Lima, Perú
          </p>
          <div className="app__hero-stats">
            <div className="app__stat-card">
              <div className="app__stat-number">50+</div>
              <div className="app__stat-label">Clientes Satisfechos</div>
            </div>
            <div className="app__stat-card">
              <div className="app__stat-number">5+</div>
              <div className="app__stat-label">Años en el Rubro</div>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="app__why-choose">
        <div className="container">
          <h2 className="app__section-title">¿Por Qué Elegirnos?</h2>
          <div className="app__features-grid">
            <div className="app__feature-card">
              <div className="app__feature-icon">🏆</div>
              <h3 className="app__feature-title">Resultados de Calidad</h3>
              <p className="app__feature-description">
                Más de 5 años de experiencia garantizan resultados profesionales que superan tus expectativas.
              </p>
            </div>
            <div className="app__feature-card">
              <div className="app__feature-icon">❤️</div>
              <h3 className="app__feature-title">Atención Personalizada</h3>
              <p className="app__feature-description">
                Cada cliente es único. Adaptamos nuestros servicios a tus necesidades específicas.
              </p>
            </div>
            <div className="app__feature-card">
              <div className="app__feature-icon">🏠</div>
              <h3 className="app__feature-title">Comodidad en Casa</h3>
              <p className="app__feature-description">
                Servicio a domicilio que te permite disfrutar de muebles limpios sin salir de casa.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Products Section - Preview */}
      <section id="products" className="app__products">
        <div className="container">
          <h2 className="app__section-title">Productos Destacados</h2>
          <p className="app__section-subtitle">
            Los más vendidos y productos en oferta especial
          </p>
          
          <div className="app__products-preview">
            <div className="app__preview-grid">
              {featuredProducts.map(product => (
                <div key={product.id} className="app__product-card">
                  {product.badge && (
                    <div className={`app__product-badge app__product-badge--${product.badge.toLowerCase().replace(/¡|!/g, '').replace(/á/g, 'a').replace(/\s+/g, '')}`}>
                      {product.badge}
                    </div>
                  )}

                  <div className="app__product-card-header">
                    <div className="app__product-image">{product.image}</div>
                    <div className="app__product-card-info">
                      <h4 className="app__product-title">{product.name}</h4>
                      <div className="app__product-category-badge">
                        {product.category}
                      </div>
                    </div>
                  </div>

                  <div className="app__product-pricing">
                    <div className="app__product-price-section">
                      <div className="app__product-price-main">
                        {product.originalPrice && (
                          <span className="app__product-price-original">
                            S/ {product.originalPrice.toFixed(2)}
                          </span>
                        )}
                        <span className="app__product-price-current">
                          S/ {product.price.toFixed(2)}
                        </span>
                      </div>
                      <div className="app__product-stock">
                        <span className="app__product-stock-icon">📦</span>
                        <span className="app__product-stock-text">{product.inStock ? 'En stock' : 'Agotado'}</span>
                      </div>
                    </div>

                    {product.originalPrice && product.originalPrice > product.price && (
                      <div className="app__product-savings">
                        Ahorras S/ {(product.originalPrice - product.price).toFixed(2)}
                      </div>
                    )}
                  </div>

                  <div className="app__product-description">
                    <p>{product.description}</p>
                  </div>

                  <div className="app__product-features">
                    <ul className="app__product-features-list">
                      {product.features.slice(0, 3).map((feature: string, index: number) => (
                        <li key={index} className="app__product-feature">
                          <span className="app__product-feature-icon">✓</span>
                          {feature}
                        </li>
                      ))}
                      {product.features.length > 3 && (
                        <li className="app__product-feature app__product-feature--more">
                          +{product.features.length - 3} más
                        </li>
                      )}
                    </ul>
                  </div>

                  <div className="app__product-rating">
                    <div className="app__product-stars">
                      {renderStars(product.rating)}
                    </div>
                    <span className="app__product-rating-text">
                      {product.rating} ({product.reviews} reseñas)
                    </span>
                  </div>

                  <div className="app__product-actions">
                    <Button 
                      variant="primary" 
                      className="app__product-add-btn"
                      onClick={() => addToCart({
                        id: product.id,
                        type: 'product',
                        name: product.name,
                        price: product.price,
                        image: product.image
                      })}
                    >
                      Añadir al Carrito
                    </Button>
                    <Button 
                      variant="outline"
                      className="app__product-info-btn"
                    >
                      Más Info
                    </Button>
                  </div>
                </div>
              ))}

              <div className="app__product-card app__product-card--more">
                <div className="app__more-products">
                  <div className="app__more-icon">🛍️</div>
                  <div className="app__more-text">+15 Productos</div>
                  <p className="app__more-subtitle">Descubre todo nuestro catálogo</p>
                  <Button 
                    variant="primary" 
                    onClick={() => handleNavigation('products')}
                  >
                    Ver Catálogo Completo
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section - Preview */}
      <section id="services" className="app__services">
        <div className="container">
          <h2 className="app__section-title">Nuestros Servicios</h2>
          <p className="app__section-subtitle">
            Servicios profesionales de limpieza con precios competitivos
          </p>
          <div className="app__services-grid">
            {featuredServices.map(service => (
              <div key={service.id} className="app__service-card">
                <div className="app__service-card-header">
                  <div className="app__service-image">{service.image}</div>
                  <div className="app__service-card-info">
                    <h3 className="app__service-title">{service.name}</h3>
                    <div className="app__service-category-badge">
                      {service.category}
                    </div>
                  </div>
                </div>

                <div className="app__service-pricing">
                  <div className="app__service-price-section">
                    <div className="app__service-price-main">
                      <span className="app__service-price-current">
                        Desde S/ {service.startingPrice.toFixed(2)}
                      </span>
                    </div>
                    <div className="app__service-duration">
                      <span className="app__service-duration-icon">⏱️</span>
                      <span className="app__service-duration-text">{service.estimatedDuration}</span>
                    </div>
                  </div>
                </div>

                <div className="app__service-description">
                  <p>{service.description}</p>
                </div>

                <div className="app__service-features">
                  <ul className="app__service-features-list">
                    {service.features.slice(0, 3).map((feature: string, index: number) => (
                      <li key={index} className="app__service-feature">
                        <span className="app__service-feature-icon">✓</span>
                        {feature}
                      </li>
                    ))}
                    {service.features.length > 3 && (
                      <li className="app__service-feature app__service-feature--more">
                        +{service.features.length - 3} más
                      </li>
                    )}
                  </ul>
                </div>

                <div className="app__service-rating">
                  <div className="app__service-stars">
                    {renderStars(service.rating)}
                  </div>
                  <span className="app__service-rating-text">
                    {service.rating} ({service.reviews} reseñas)
                  </span>
                </div>

                <div className="app__service-actions">
                  <Button 
                    variant="primary" 
                    className="app__service-book-btn"
                    onClick={() => addToCart({
                      id: service.id,
                      type: 'service',
                      name: service.name,
                      price: service.startingPrice,
                      image: service.image
                    })}
                  >
                    Agregar al Carrito
                  </Button>
                  <Button 
                    variant="outline"
                    className="app__service-info-btn"
                  >
                    Más Info
                  </Button>
                </div>
              </div>
            ))}
            
            <div className="app__service-card app__service-card--more">
              <div className="app__more-services">
                <div className="app__more-icon">➕</div>
                <div className="app__more-text">+12 Servicios</div>
                <p className="app__more-subtitle">Descubre todos nuestros servicios</p>
                <Button 
                  variant="outline" 
                  onClick={() => handleNavigation('services')}
                >
                  Ver Todos los Servicios
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  )

  return (
    <div className="app">
      <Header 
        siteName="FloresCore"
        onQuoteRequest={handleQuoteRequest}
        phoneNumber="+51 999 888 777"
        onNavigation={handleNavigation}
        currentPage={currentPage}
        isLoggedIn={isLoggedIn}
        user={user ? { name: user.firstName, email: user.email, role: user.role } : null}
        onLogout={handleLogout}
        cartItemCount={getCartItemCount()}
      />
      
      <main className="app__main">
        {renderPage()}
      </main>
    </div>
  )
}

export default App